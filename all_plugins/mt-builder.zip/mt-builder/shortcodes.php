<?php

/**
 * @author madars.bitenieks
 * @copyright 2016
 * 
 */



 
function slider_content( $atts , $content = null) {
	extract( shortcode_atts( array(
            'title' => '',
            'subtitle' => ''
            
        ), $atts));
   return '<div class="mt-slider-content"><h2>'. $title .'</h2><h3>'. $subtitle .'</h3><p>' . do_shortcode($content) . '<p></div>';
}
add_shortcode('slider_content', 'slider_content');



function mt_spacer( $atts , $content = null) {
	extract( shortcode_atts( array(
            'size' => ''
            
        ), $atts));
   return '<div style="height: '. $size .'px"></div>';
}
add_shortcode('mt_spacer', 'mt_spacer');
  
 
 
 
if (class_exists('WPBakeryShortCode')) { 
	


/* Staff */

add_shortcode( 'mt_cost', 'mt_cost_func' );
	function mt_cost_func( $atts ) {

        extract(shortcode_atts(array(
	        'cost_calculator_id' => '1',
	        'cost_calculator_button_text' => 'We will contact you within one business day.',
	        'cost_calculator_icon' => '',
	        'cost_calculator_email' => 'madza@madzathemes.com',
	        
	        
            'option_1' => '',
            'option_1_name' => '',
            'option_1_type' => '',
            'option_1_value_size' => '1',
            'option_1_value_slider_value' => '0',
            'option_1_value_slider_from' => '0',
            'option_1_value_slider_to' => '100',
            'option_1_value_slider_step' => '1',
            'option_1_value_checkbox' => '0',
            'option_1_value_select' => '',
            'option_1_value_select_title' => '',
            'option_1_value_select_value' => '',
            
            'option_2' => '',
            'option_2_name' => '',
            'option_2_type' => '',
            'option_2_value_size' => '1',
            'option_2_value_mach' => '',
            'option_2_value_slider_value' => '0',
            'option_2_value_slider_from' => '0',
            'option_2_value_slider_to' => '100',
            'option_2_value_slider_step' => '1',
            'option_2_value_checkbox' => '0',
            'option_2_value_select' => '',
            'option_2_value_select_title' => '',
            'option_2_value_select_value' => '',
            
            'option_3' => '',
            'option_3_name' => '',
            'option_3_type' => '',
            'option_3_value_size' => '1',
            'option_3_value_mach' => '',
            'option_3_value_slider_value' => '0',
            'option_3_value_slider_from' => '0',
            'option_3_value_slider_to' => '100',
            'option_3_value_slider_step' => '1',
            'option_3_value_checkbox' => '0',
            'option_3_value_select' => '',
            'option_3_value_select_title' => '',
            'option_3_value_select_value' => '',
            
            'option_4' => '',
            'option_4_name' => '',
            'option_4_type' => '',
            'option_4_value_size' => '1',
            'option_4_value_mach' => '',
            'option_4_value_slider_value' => '0',
            'option_4_value_slider_from' => '0',
            'option_4_value_slider_to' => '100',
            'option_4_value_slider_step' => '1',
            'option_4_value_checkbox' => '0',
            'option_4_value_select' => '',
            'option_4_value_select_title' => '',
            'option_4_value_select_value' => '',
            
            'option_5' => '',
            'option_5_name' => '',
            'option_5_type' => '',
            'option_5_value_size' => '1',
            'option_5_value_mach' => '',
            'option_5_value_slider_value' => '0',
            'option_5_value_slider_from' => '0',
            'option_5_value_slider_to' => '100',
            'option_5_value_slider_step' => '1',
            'option_5_value_checkbox' => '0',
            'option_5_value_select' => '',
            'option_5_value_select_title' => '',
            'option_5_value_select_value' => '',
            
            'option_6' => '',
            'option_6_name' => '',
            'option_6_type' => '',
            'option_6_value_size' => '1',
            'option_6_value_mach' => '',
            'option_6_value_slider_value' => '0',
            'option_6_value_slider_from' => '0',
            'option_6_value_slider_to' => '100',
            'option_6_value_slider_step' => '1',
            'option_6_value_checkbox' => '0',
            'option_6_value_select' => '',
            'option_6_value_select_title' => '',
            'option_6_value_select_value' => '',
            
            'option_7' => '',
            'option_7_name' => '',
            'option_7_type' => '',
            'option_7_value_size' => '1',
            'option_7_value_mach' => '',
            'option_7_value_slider_value' => '0',
            'option_7_value_slider_from' => '0',
            'option_7_value_slider_to' => '100',
            'option_7_value_slider_step' => '1',
            'option_7_value_checkbox' => '0',
            'option_7_value_select' => '',
            'option_7_value_select_title' => '',
            'option_7_value_select_value' => '',
            
            'option_8' => '',
            'option_8_name' => '',
            'option_8_type' => '',
            'option_8_value_size' => '1',
            'option_8_value_mach' => '',
            'option_8_value_slider_value' => '0',
            'option_8_value_slider_from' => '0',
            'option_8_value_slider_to' => '100',
            'option_8_value_slider_step' => '1',
            'option_8_value_checkbox' => '0',
            'option_8_value_select' => '',
            'option_8_value_select_title' => '',
            'option_8_value_select_value' => '',
            
            'option_9' => '',
            'option_9_name' => '',
            'option_9_type' => '',
            'option_9_value_size' => '1',
            'option_9_value_mach' => '',
            'option_9_value_slider_value' => '0',
            'option_9_value_slider_from' => '0',
            'option_9_value_slider_to' => '100',
            'option_9_value_slider_step' => '1',
            'option_9_value_checkbox' => '0',
            'option_9_value_select' => '',
            'option_9_value_select_title' => '',
            'option_9_value_select_value' => '',
            
            'option_10' => '',
            'option_10_name' => '',
            'option_10_type' => '',
            'option_10_value_size' => '1',
            'option_10_value_mach' => '',
            'option_10_value_slider_value' => '0',
            'option_10_value_slider_from' => '0',
            'option_10_value_slider_to' => '100',
            'option_10_value_slider_step' => '1',
            'option_10_value_checkbox' => '0',
            'option_10_value_select' => '',
            'option_10_value_select_title' => '',
            'option_10_value_select_value' => '',
            
            
        ), $atts));
        
        $output =  $plus = $multiply_plus = $multiply = $multiply_plus_2 = $multiply_plus_3 = $multiply_plus_4 = $multiply_plus_5 = $multiply_plus_6 = $multiply_plus_7 = $multiply_plus_8 = $multiply_plus_9 = $multiply_plus_10 = $multiply_2 = $multiply_3 = $multiply_4 = $multiply_5 = $multiply_6 = $multiply_7 = $multiply_8 = $multiply_9 = $multiply_10 = $plus_2 = $plus_3 = $plus_4 = $plus_5 = $plus_6 = $plus_7 = $plus_8 = $plus_9 = $plus_10 = $m_2 = $m_3 = $m_4 = $m_5 = $m_6 = $m_7 = $m_8 = $m_9 = $m_10 = "";
        
        
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_1_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_1_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_1" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_1_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_1"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_1_input hidden"  type="number" value="'. $option_1_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_1 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_1_value_slider_value .', 
												min: 	'. $option_1_value_slider_from .', 
												max: 	'. $option_1_value_slider_to .', 
												step:	'. $option_1_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_1_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_1_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_1_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_1_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_1" class="mt_cost_select"><option 	selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_1_value_select_value'].'">'. $value['option_1_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_1_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_1" class="mt_cost_checkbox"  type="checkbox" value="'. $option_1_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        
        
        if($option_2 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_2_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_2_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_2" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_2_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_2"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_2_input hidden"  type="number" value="'. $option_2_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_2 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_2_value_slider_value .', 
												min: 	'. $option_2_value_slider_from .', 
												max: 	'. $option_2_value_slider_to .', 
												step:	'. $option_2_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_2_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_2_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_2_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_2_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_2" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_2_value_select_value'].'">'. $value['option_2_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_2_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_2" class="mt_cost_checkbox"  type="checkbox" value="'. $option_2_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        if($option_3 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_3_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_3_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_3" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_3_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_3"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_3_input hidden"  type="number" value="'. $option_3_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_3 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_3_value_slider_value .', 
												min: 	'. $option_3_value_slider_from .', 
												max: 	'. $option_3_value_slider_to .', 
												step:	'. $option_3_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_3_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_3_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_3_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_3_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_3" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_3_value_select_value'].'">'. $value['option_3_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_3_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_3" class="mt_cost_checkbox"  type="checkbox" value="'. $option_3_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        if($option_4 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_4_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_4_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_4" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_4_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_4"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_4_input hidden"  type="number" value="'. $option_4_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_4 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_4_value_slider_value .', 
												min: 	'. $option_4_value_slider_from .', 
												max: 	'. $option_4_value_slider_to .', 
												step:	'. $option_4_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_4_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_4_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_4_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_4_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_4" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_4_value_select_value'].'">'. $value['option_4_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_4_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_4" class="mt_cost_checkbox"  type="checkbox" value="'. $option_4_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        
        if($option_5 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_5_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_5_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_5" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_5_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_5"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_5_input hidden"  type="number" value="'. $option_5_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_5 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_5_value_slider_value .', 
												min: 	'. $option_5_value_slider_from .', 
												max: 	'. $option_5_value_slider_to .', 
												step:	'. $option_5_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_5_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_5_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_5_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_5_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_5" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_5_value_select_value'].'">'. $value['option_5_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_5_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_5" class="mt_cost_checkbox"  type="checkbox" value="'. $option_5_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        
        if($option_6 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_6_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_6_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_6" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_6_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_6"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_6_input hidden"  type="number" value="'. $option_6_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_6 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_6_value_slider_value .', 
												min: 	'. $option_6_value_slider_from .', 
												max: 	'. $option_6_value_slider_to .', 
												step:	'. $option_6_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_6_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_6_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_6_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_6_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_6" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_6_value_select_value'].'">'. $value['option_6_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_6_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_6" class="mt_cost_checkbox"  type="checkbox" value="'. $option_6_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        
        if($option_7 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_7_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_7_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_7" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_7_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_7"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_7_input hidden"  type="number" value="'. $option_7_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_7 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_7_value_slider_value .', 
												min: 	'. $option_7_value_slider_from .', 
												max: 	'. $option_7_value_slider_to .', 
												step:	'. $option_7_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_7_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_7_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_7_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_7_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_7" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_7_value_select_value'].'">'. $value['option_7_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_7_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_7" class="mt_cost_checkbox"  type="checkbox" value="'. $option_7_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        
        if($option_8 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_8_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_8_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_8" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_8_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_8"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_8_input hidden"  type="number" value="'. $option_8_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_8 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_8_value_slider_value .', 
												min: 	'. $option_8_value_slider_from .', 
												max: 	'. $option_8_value_slider_to .', 
												step:	'. $option_8_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_8_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_8_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_8_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_8_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_8" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_8_value_select_value'].'">'. $value['option_8_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_8_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_8" class="mt_cost_checkbox"  type="checkbox" value="'. $option_8_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        if($option_9 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_9_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_9_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_9" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_9_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_9"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_9_input hidden"  type="number" value="'. $option_9_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_9 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_9_value_slider_value .', 
												min: 	'. $option_9_value_slider_from .', 
												max: 	'. $option_9_value_slider_to .', 
												step:	'. $option_9_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_9_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_9_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_9_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_9_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_9" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_9_value_select_value'].'">'. $value['option_9_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_9_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_9" class="mt_cost_checkbox"  type="checkbox" value="'. $option_9_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        
        if($option_10 == "On") {
	        
	        $output .= '<div class="mt_coust_box container">';
	        
	        	$output .= '<div class="row">';
	        
			        $output .= '<label class="col-md-6">'.$option_10_name.':</label>';
			        
			        $output .= '<div class="mt_coust_input col-md-6">';
			        
			        
				        if($option_10_type == "textfield") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_10" class="mt_cost_textfield" type="number" value="0">';
					        
				        }
				        
				        if($option_10_type == "slider") {
					        
					        $slider_toltip_class ="'tooltip'";
					        $output .= '<div id="mt_'. $cost_calculator_id .'_option_10"><div class="mt_cost_slider"></div><input class=" mt_'. $cost_calculator_id .'_option_10_input hidden"  type="number" value="'. $option_10_value_slider_value .'"></div>';
					        
					        $output  .= '<script type="text/javascript">';
								$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
									$output .= '"use strict";';
									
									$output .= 'jQuery("#mt_'. $cost_calculator_id .'_option_10 .mt_cost_slider").slider({
												range: "min", 
												value:	'. $option_10_value_slider_value .', 
												min: 	'. $option_10_value_slider_from .', 
												max: 	'. $option_10_value_slider_to .', 
												step:	'. $option_10_value_slider_step .', 
												slide: function(event, ui) {  jQuery(ui.handle).find(".tooltip").text(ui.value); jQuery(".mt_'. $cost_calculator_id .'_option_10_input").attr("value", ui.value);   }, 
												create: function(event, ui) {  var tooltip = jQuery("<div /><span class='. $slider_toltip_class .'>'. $option_10_value_slider_value .'</span>");  jQuery(event.target).find(".ui-slider-handle").append(tooltip);  }, 
												change: function(event, ui) {   } 
											});';
									
								$output .= '});';
							$output .= '</script>'; 
					        
				        }
				        
				        if($option_10_type == "select") {
					        
					        $titles = vc_param_group_parse_atts( $atts['option_10_value_select'] );
					        
					        $output .= '<select id="mt_'. $cost_calculator_id .'_option_10" class="mt_cost_select"><option selected="selected" value="0">Choose...</option>';
						        foreach ($titles as $value) {
								    $output .= '<option value="'. $value['option_10_value_select_value'].'">'. $value['option_10_value_select_title'].'</option>';
								}
					        $output .= '</select>';
					        
				        }
				        
				        if($option_10_type == "checkbox") {
					        
					        $output .= '<input id="mt_'. $cost_calculator_id .'_option_10" class="mt_cost_checkbox"  type="checkbox" value="'. $option_10_value_checkbox .'">';
					        
				        }
				        
			        
			        $output .= '</div>';
	        
	        	$output .= '</div>';
	        
	        $output .= '</div>';
        }
        
        $output .= '<div class="mt_coust_result">
        				<div class="row">
        					<div class="col-md-4"><i class="'. $cost_calculator_icon .'"></i></div>
        					<div class="col-md-8">
        						<div class="mt_cost_price"><span>$</span><span id="mt_coust_result">0</span><span>.00</span></div>
        						<div class="mt_cost_price_text">Approximate Project Cost</div>
        					</div>
        				</div>
        			</div>';
		
		
		
		$output .= '<div class="mt_cost_mesage">
						<div class="row">
							<div class="col-md-6">
								<input type="text" name="fname"   placeholder="'. esc_html__( 'Your Name*', 'builder69' ) .'" id="fname" value="" size="40">
								<input type="email" name="email"  placeholder="'. esc_html__( 'Your Email*', 'builder69' ) .'" id="email" size="40" >
								<input type="text" name="phone"   placeholder="'. esc_html__( 'Your Phone', 'builder69' ) .'"id="phone" size="40" >
								<input type="text" value="'.$cost_calculator_email.'" class="hidden" name="cost_calculator_email"  id="cost_calculator_email" size="40" >
								
								<textarea class="hidden" name="cost"  id="cost" size="40" ></textarea>
								<textarea class="hidden" name="cost_calculator_content"  id="cost_calculator_content" size="40" >TEST</textarea>
								<p class="mt_cost_button_text">'.$cost_calculator_button_text.'</p>
							</div>
							<div class="col-md-6">
							<textarea name="message"   placeholder="'. esc_html__( 'Message*', 'builder69' ) .'" cols="40" id="message" rows="10"></textarea>
							<input type="submit" class="wpcf7-submit pull-right" value="SUBMIT NOW"/>
		        			</div>
	        			</div>
	        			<div class="contact_ajax_response"></div>
        			</div>';
		
		
		$output  .= '<script type="text/javascript">';
			$output .= 'jQuery.noConflict(); jQuery(document).ready(function(){ ';
				$output .= '"use strict";';
				$output .= 'jQuery(".mt_cost_calculator input, #mb-content, .ui-slider-handle").bind("change paste keyup input submit click mouseenter ontouchend relatedTarget", function(e){';
					
					
						if($option_1_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_1 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_1").val()*'.$option_1_value_size.');'; }
						if($option_1_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_1 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_1 option:checked").val()*'.$option_1_value_size.');'; }
						if($option_1_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_1 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_1 .mt_'. $cost_calculator_id .'_option_1_input").val()*'.$option_1_value_size.');'; }
						if($option_1_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_1").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_1 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_1:checked").val()*'.$option_1_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_1 = "0"; }'; }
							
					
					
					if($option_2 == "On") { 
						if($option_2_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_2 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_2").val()*'.$option_2_value_size.');'; }
						if($option_2_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_2 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_2  option:checked").val()*'.$option_2_value_size.');'; }
						if($option_2_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_2 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_2 .mt_'. $cost_calculator_id .'_option_2_input").val()*'.$option_2_value_size.');'; }
						if($option_3_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_2").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_2 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_2:checked").val()*'.$option_2_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_2 = "0"; }'; }
						
						if($option_2_value_mach == "plus_multiply") { $multiply_plus_2 = '+ mt_'. $cost_calculator_id .'_option_2'; } 
						if($option_2_value_mach == "multiply") 		{ $multiply_2 = 'mt_'. $cost_calculator_id .'_option_2'; }
						if($option_2_value_mach == "plus") 			{ $plus_2 = '+ mt_'. $cost_calculator_id .'_option_2'; } 
						
					}
					if($option_3 == "On") { 
						
						if($option_3_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_3 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_3").val()*'.$option_3_value_size.');'; }
						if($option_3_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_3 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_3 option:checked").val()*'.$option_3_value_size.');'; }
						if($option_3_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_3 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_3 .mt_'. $cost_calculator_id .'_option_3_input").val()*'.$option_3_value_size.');'; }
						if($option_3_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_3").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_3 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_3:checked").val()*'.$option_3_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_3 = "0"; }'; }
						
						
						
						if($option_3_value_mach == "plus_multiply") { $multiply_plus_3 = '+ mt_'. $cost_calculator_id .'_option_3'; }
						if($option_3_value_mach == "multiply") 		{ $multiply_3 = 'mt_'. $cost_calculator_id .'_option_3'; }
						if($option_3_value_mach == "plus") 			{ $plus_3 = '+ mt_'. $cost_calculator_id .'_option_3'; }
					}
					
					if($option_4 == "On") { 
						if($option_4_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_4 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_4").val()*'.$option_4_value_size.');'; }
						if($option_4_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_4 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_4 option:checked").val()*'.$option_4_value_size.');'; }
						if($option_4_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_4 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_4 .mt_'. $cost_calculator_id .'_option_4_input").val()*'.$option_4_value_size.');'; }
						if($option_4_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_4").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_4 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_4:checked").val()*'.$option_4_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_4 = "0"; }'; }
				
						if($option_4_value_mach == "plus_multiply") { $multiply_plus_4 = '+ mt_'. $cost_calculator_id .'_option_4'; }
						if($option_4_value_mach == "multiply") 		{ $multiply_4 = 'mt_'. $cost_calculator_id .'_option_4'; }
						if($option_4_value_mach == "plus") 			{ $plus_4 = '+ mt_'. $cost_calculator_id .'_option_4'; }
						
					}
					
					if($option_5 == "On") { 
						if($option_5_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_5 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_5").val()*'.$option_5_value_size.');'; }
						if($option_5_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_5 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_5 option:checked").val()*'.$option_5_value_size.');'; }
						if($option_5_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_5 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_5 .mt_'. $cost_calculator_id .'_option_5_input").val()*'.$option_5_value_size.');'; }
						if($option_5_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_5").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_5 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_5:checked").val()*'.$option_5_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_5 = "0"; }'; }
						
						if($option_5_value_mach == "plus_multiply") { $multiply_plus_5 = '+ mt_'. $cost_calculator_id .'_option_5'; }
						if($option_5_value_mach == "multiply") 		{ $multiply_5 = 'mt_'. $cost_calculator_id .'_option_5'; }
						if($option_5_value_mach == "plus") 			{ $plus_5 = '+ mt_'. $cost_calculator_id .'_option_5'; }
						
					}
					
					if($option_6 == "On") { 
						if($option_6_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_6 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_6").val()*'.$option_6_value_size.');'; }
						if($option_6_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_6 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_6 option:checked").val()*'.$option_6_value_size.');'; }
						if($option_6_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_6 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_6 .mt_'. $cost_calculator_id .'_option_6_input").val()*'.$option_6_value_size.');'; }
						if($option_6_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_6").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_6 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_6:checked").val()*'.$option_6_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_6 = "0"; }'; }
						
						if($option_6_value_mach == "plus_multiply") { $multiply_plus_6 = '+ mt_'. $cost_calculator_id .'_option_6'; }
						if($option_6_value_mach == "multiply") 		{ $multiply_6 = 'mt_'. $cost_calculator_id .'_option_6'; }
						if($option_6_value_mach == "plus") 			{ $plus_6 = '+ mt_'. $cost_calculator_id .'_option_6'; }
						
					}
					
					if($option_7 == "On") { 
						if($option_7_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_7 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_7").val()*'.$option_7_value_size.');'; }
						if($option_7_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_7 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_7 option:checked").val()*'.$option_7_value_size.');'; }
						if($option_7_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_7 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_7 .mt_'. $cost_calculator_id .'_option_7_input").val()*'.$option_7_value_size.');'; }
						if($option_7_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_7").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_7 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_7:checked").val()*'.$option_7_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_7 = "0"; }'; }
						
						if($option_7_value_mach == "plus_multiply") { $multiply_plus_7 = '+ mt_'. $cost_calculator_id .'_option_7'; }
						if($option_7_value_mach == "multiply") 		{ $multiply_7 = 'mt_'. $cost_calculator_id .'_option_7'; }
						if($option_7_value_mach == "plus") 			{ $plus_7 = '+ mt_'. $cost_calculator_id .'_option_7'; }
						
					}
					
					if($option_8 == "On") { 
						if($option_8_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_8 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_8").val()*'.$option_8_value_size.');'; }
						if($option_8_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_8 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_8 option:checked").val()*'.$option_8_value_size.');'; }
						if($option_8_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_8 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_8 .mt_'. $cost_calculator_id .'_option_8_input").val()*'.$option_8_value_size.');'; }
						if($option_8_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_8").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_8 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_8:checked").val()*'.$option_8_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_8 = "0"; }'; }
						
						if($option_8_value_mach == "plus_multiply") { $multiply_plus_8 = '+ mt_'. $cost_calculator_id .'_option_8'; }
						if($option_8_value_mach == "multiply") 		{ $multiply_8 = 'mt_'. $cost_calculator_id .'_option_8'; }
						if($option_8_value_mach == "plus") 			{ $plus_8 = '+ mt_'. $cost_calculator_id .'_option_8'; }
						
					}
					
					if($option_9 == "On") { 
						if($option_9_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_9 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_9").val()*'.$option_9_value_size.');'; }
						if($option_9_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_9 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_9 option:checked").val()*'.$option_9_value_size.');'; }
						if($option_9_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_9 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_9 .mt_'. $cost_calculator_id .'_option_9_input").val()*'.$option_9_value_size.');'; }
						if($option_9_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_9").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_9 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_9:checked").val()*'.$option_9_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_9 = "0"; }'; }
						
						if($option_9_value_mach == "plus_multiply") { $multiply_plus_9 = '+ mt_'. $cost_calculator_id .'_option_9'; }
						if($option_9_value_mach == "multiply") 		{ $multiply_9 = 'mt_'. $cost_calculator_id .'_option_9'; }
						if($option_9_value_mach == "plus") 			{ $plus_9 = '+ mt_'. $cost_calculator_id .'_option_9'; }
						
					}
					
					if($option_10 == "On") { 
						if($option_10_type == "textfield") 	{ $output .= 'var mt_'. $cost_calculator_id .'_option_10 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_10").val()*'.$option_10_value_size.');'; }
						if($option_10_type == "select") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_10 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_10 option:checked").val()*'.$option_10_value_size.');'; }
						if($option_10_type == "slider") 		{ $output .= 'var mt_'. $cost_calculator_id .'_option_10 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_10 .mt_'. $cost_calculator_id .'_option_10_input").val()*'.$option_10_value_size.');'; }
						if($option_10_type == "checkbox") 	{ $output .= 'if(jQuery("#mt_'. $cost_calculator_id .'_option_10").prop("checked") == true){ var mt_'. $cost_calculator_id .'_option_10 = parseInt(jQuery(".mt_cost_calculator #mt_'. $cost_calculator_id .'_option_10:checked").val()*'.$option_10_value_size.'); } else { var mt_'. $cost_calculator_id .'_option_10 = "0"; }'; }
						
						if($option_10_value_mach == "plus_multiply") { $multiply_plus_10 = '+ mt_'. $cost_calculator_id .'_option_10'; }
						if($option_10_value_mach == "multiply") 		{ $multiply_10 = 'mt_'. $cost_calculator_id .'_option_10'; }
						if($option_10_value_mach == "plus") 			{ $plus_10 = '+ mt_'. $cost_calculator_id .'_option_10'; }
						
					}
					
					
					if($plus_2 == "" and $plus_3 == "" and $plus_4 == "" and $plus_5 == "" and $plus_6 == "" and $plus_7 == "" and $plus_8 == "" and $plus_9 == "" and $plus_10 == "") {} else {
						$output .= 'var mt_plus = '.$plus_2.''.$plus_3.''.$plus_4.''.$plus_5.''.$plus_6.''.$plus_7.''.$plus_8.''.$plus_9.''.$plus_10.';';
					}
					
					if($multiply_plus_2 == "" and $multiply_plus_3 == "" and $multiply_plus_4 == "" and $multiply_plus_5 == "" and $multiply_plus_6 == "" and $multiply_plus_7 == "" and $multiply_plus_8 == "" and $multiply_plus_9 == "" and $multiply_plus_10 == "") {} else { 
						$output .= 'var mt_multiply_plus = '.$multiply_plus_2.''.$$multiply_plus_3.''.$multiply_plus_4.''.$multiply_plus_5.''.$multiply_plus_6.''.$multiply_plus_7.''.$multiply_plus_8.''.$multiply_plus_9.''.$multiply_plus_10.';';
					}
			        
			        
			        
			        $output .= 'var result = mt_'. $cost_calculator_id .'_option_1 '; 
			        
			        if($multiply_2!="") {$m_2 = "*";} 
			        if($multiply_3!="") {$m_3 = "*";}
			        if($multiply_4!="") {$m_4 = "*";}
			        if($multiply_5!="") {$m_5 = "*";}
			        if($multiply_6!="") {$m_6 = "*";}
			        if($multiply_7!="") {$m_7 = "*";}
			        if($multiply_8!="") {$m_8 = "*";}
			        if($multiply_9!="") {$m_9 = "*";}
			        if($multiply_10!="") {$m_10 = "*";}
			        
			        if($multiply_2 == "" and $multiply_3 == "" and $multiply_4 == "" and $multiply_5 == "" and $multiply_6 == "" and $multiply_7 == "" and $multiply_8 == "" and $multiply_9 == "" and $multiply_10 == "") {} else {
				        $output .= ''.$m_2.''.$multiply_2.''.$m_3.''.$multiply_3.''.$m_4.''.$multiply_4.''.$m_5.''.$multiply_5.''.$m_6.''.$multiply_6.''.$m_7.''.$multiply_7.''.$m_8.''.$multiply_8.''.$m_9.''.$multiply_9.''.$m_10.''.$multiply_10.'';
			        }
			        if($multiply_plus_2 == "" and $multiply_plus_3 == "" and $multiply_plus_4 == "" and $multiply_plus_5 == "" and $multiply_plus_6 == "" and $multiply_plus_7 == "" and $multiply_plus_8 == "" and $multiply_plus_9 == "" and $multiply_plus_10 == "") {} else {
				        $output .= '* (mt_multiply_plus) ';
			        }
			        if($plus_2 == "" and $plus_3 == "" and $plus_4 == "" and $plus_5 == "" and $plus_6 == "" and $plus_7 == "" and $plus_8 == "" and $plus_9 == "" and $plus_10 == "") {} else {
				        $output .= '+ mt_plus ';
			        }
			        
			        $output .= ';';
			        
			        			        
			        
					$output .= '  jQuery.fn.digits = function(){  return this.each(function(){  jQuery(this).text( jQuery(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); })} 
					 jQuery(".mt_cost_id_'. $cost_calculator_id .' #mt_coust_result").html(result).digits();
					 jQuery(".mt_cost_id_'. $cost_calculator_id .' #cost").html(result).digits(); ';
					
				$output .= '});';	
				
			$output .= '});';
		$output .= '</script>';
		
	
    
        return '<div class="mt_cost_calculator mt_cost_id_'. $cost_calculator_id .'"><form id="contact" novalidate="novalidate">'.$output.'</form></div>';
    }


add_action( 'vc_before_init', 'mt_cost_func_fields' );
function mt_cost_func_fields() {
vc_map( array(
    "base"        => "mt_cost",
    "name"        => esc_html__("Cost Calculator", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "mt_module_cost_calculator",
    "category" => "Madza Moduls",
    "params"    => array(
	 
	    array(
            "type" => "textfield",
            "heading" => esc_html__("ID", "madza_builder69"),
            "param_name" => "cost_calculator_id",
            "description" => "Make this calculator unique. Default: 1",
            "value" => "1"
			
        ),
	    array(
            "type" => "textfield",
            "heading" => esc_html__("Cost Calculator ID", "madza_builder69"),
            "param_name" => "cost_calculator_id",
            "description" => "Make this calculator unique. Default: 1",
            "value" => "1",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Cost Calculator Email", "madza_builder69"),
            "param_name" => "cost_calculator_email",
            "description" => "Sample: info@yourdomain.com",
            'admin_label' => true,
            "value" => "",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Cost Calculator Bottom Text", "madza_builder69"),
            "param_name" => "cost_calculator_button_text",
            "description" => "Default: We will contact you within one business day.",
            "value" => "",
        ),
        array(
            "type" => "madza_icons",
            "heading" => esc_html__("Cost Calculator Icon", "madza_builder69"),
            "param_name" => "cost_calculator_icon",
            "description" => "",
            "value" => "",
        ),
        
        	    
	    
	    /* Option 1 */
	   
		array(
            "type" => "textfield",
            "heading" => esc_html__("Name", "madza_builder69"),
            "param_name" => "option_1_name",
	        "group" => "Option 1"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Type", "madza_builder69"),
            "param_name" => "option_1_type",
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 1"
        ),        
        
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Slider Default Value", "madza_builder69"),
            "param_name" => "option_1_value_slider_value",
            "dependency" => array( 'element' => 'option_1_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 1"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Slider Value From", "madza_builder69"),
            "param_name" => "option_1_value_slider_from",
            "dependency" => array( 'element' => 'option_1_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 1"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Slider Value To", "madza_builder69"),
            "param_name" => "option_1_value_slider_to",
            "dependency" => array( 'element' => 'option_1_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 1"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Slider Step", "madza_builder69"),
            "param_name" => "option_1_value_slider_step",
            "dependency" => array( 'element' => 'option_1_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 1"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Default Value", "madza_builder69"),
            "param_name" => "option_1_value_textfield",
            "dependency" => array( 'element' => 'option_1_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 1"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Checkbox Value", "madza_builder69"),
            "param_name" => "option_1_value_checkbox",
            "dependency" => array( 'element' => 'option_1_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 1"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Set Select Options", "madza_builder69"),
                'param_name' => 'option_1_value_select',
                "dependency" => array( 'element' => 'option_1_type', 'value' => 'select'),
				"group" => "Option 1",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_1_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_1_value_select_value',
                    )
                )
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("One Value Size", "madza_builder69"),
            "param_name" => "option_1_value_size",
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 1"
        ),
        /* end Select */
		/* end Option 1 */
		
		
		
		
		
		/* Option 2 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 2", "madza_builder69"),
	        "param_name" => "option_2",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 2"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 name", "madza_builder69"),
            "param_name" => "option_2_name",
            "dependency" => array( 'element' => 'option_2', 'value' => 'On'),
	        "group" => "Option 2"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 2 type", "madza_builder69"),
            "param_name" => "option_2_type",
            "dependency" => array( 'element' => 'option_2', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 2"
        ),
        
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 value", "madza_builder69"),
            "param_name" => "option_2_value_slider_value",
            "dependency" => array( 'element' => 'option_2_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 2"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 value from", "madza_builder69"),
            "param_name" => "option_2_value_slider_from",
            "dependency" => array( 'element' => 'option_2_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 2"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 value to", "madza_builder69"),
            "param_name" => "option_2_value_slider_to",
            "dependency" => array( 'element' => 'option_2_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 2"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 value slider step", "madza_builder69"),
            "param_name" => "option_2_value_slider_step",
            "dependency" => array( 'element' => 'option_2_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 2"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 default value", "madza_builder69"),
            "param_name" => "option_2_value_textfield",
            "dependency" => array( 'element' => 'option_2_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 2"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 value", "madza_builder69"),
            "param_name" => "option_2_value_checkbox",
            "dependency" => array( 'element' => 'option_2_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 2"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 2 value from", "madza_builder69"),
                'param_name' => 'option_2_value_select',
                "dependency" => array( 'element' => 'option_2_type', 'value' => 'select'),
				"group" => "Option 2",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_2_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_2_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 2 Mach", "madza_builder69"),
            "param_name" => "option_2_value_mach",
            "dependency" => array( 'element' => 'option_2', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 2"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 2 value size", "madza_builder69"),
            "param_name" => "option_2_value_size",
            "dependency" => array( 'element' => 'option_2', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 2"
        ),
        /* end Select */
		/* end Option 2 */     
		
		
		
		
		
		
		/* Option 3 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 3", "madza_builder69"),
	        "param_name" => "option_3",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 3"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 name", "madza_builder69"),
            "param_name" => "option_3_name",
            "dependency" => array( 'element' => 'option_3', 'value' => 'On'),
	        "group" => "Option 3"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 3 type", "madza_builder69"),
            "param_name" => "option_3_type",
            "dependency" => array( 'element' => 'option_3', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 3"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 value", "madza_builder69"),
            "param_name" => "option_3_value_slider_value",
            "dependency" => array( 'element' => 'option_3_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 3"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 value from", "madza_builder69"),
            "param_name" => "option_3_value_slider_from",
            "dependency" => array( 'element' => 'option_3_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 3"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 value to", "madza_builder69"),
            "param_name" => "option_3_value_slider_to",
            "dependency" => array( 'element' => 'option_3_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 3"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 value slider step", "madza_builder69"),
            "param_name" => "option_3_value_slider_step",
            "dependency" => array( 'element' => 'option_3_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 3"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 default value", "madza_builder69"),
            "param_name" => "option_3_value_textfield",
            "dependency" => array( 'element' => 'option_3_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 3"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 value", "madza_builder69"),
            "param_name" => "option_3_value_checkbox",
            "dependency" => array( 'element' => 'option_3_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 3"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 3 Select", "madza_builder69"),
                'param_name' => 'option_3_value_select',
                "dependency" => array( 'element' => 'option_3_type', 'value' => 'select'),
				"group" => "Option 3",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_3_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_3_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 3 Mach", "madza_builder69"),
            "param_name" => "option_3_value_mach",
            "dependency" => array( 'element' => 'option_3', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 3"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 3 value size", "madza_builder69"),
            "param_name" => "option_3_value_size",
            "dependency" => array( 'element' => 'option_3', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 3"
        ),
        /* end Select */
		/* end Option 3 */   
        
        
        
        /* Option 4 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 4", "madza_builder69"),
	        "param_name" => "option_4",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 4"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 name", "madza_builder69"),
            "param_name" => "option_4_name",
            "dependency" => array( 'element' => 'option_4', 'value' => 'On'),
	        "group" => "Option 4"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 4 type", "madza_builder69"),
            "param_name" => "option_4_type",
            "dependency" => array( 'element' => 'option_4', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 4"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 value", "madza_builder69"),
            "param_name" => "option_4_value_slider_value",
            "dependency" => array( 'element' => 'option_4_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 4"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 value from", "madza_builder69"),
            "param_name" => "option_4_value_slider_from",
            "dependency" => array( 'element' => 'option_4_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 4"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 value to", "madza_builder69"),
            "param_name" => "option_4_value_slider_to",
            "dependency" => array( 'element' => 'option_4_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 4"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 value slider step", "madza_builder69"),
            "param_name" => "option_4_value_slider_step",
            "dependency" => array( 'element' => 'option_4_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 4"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 default value", "madza_builder69"),
            "param_name" => "option_4_value_textfield",
            "dependency" => array( 'element' => 'option_4_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 4"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 value", "madza_builder69"),
            "param_name" => "option_4_value_checkbox",
            "dependency" => array( 'element' => 'option_4_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 4"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 4 value from", "madza_builder69"),
                'param_name' => 'option_4_value_select',
                "dependency" => array( 'element' => 'option_4_type', 'value' => 'select'),
				"group" => "Option 4",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_4_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_4_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 4 Mach", "madza_builder69"),
            "param_name" => "option_4_value_mach",
            "dependency" => array( 'element' => 'option_4', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 4"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 4 value size", "madza_builder69"),
            "param_name" => "option_4_value_size",
            "dependency" => array( 'element' => 'option_4', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 4"
        ),
        /* end Select */
		/* end Option 4 */
		
		
		
		
		/* Option 5 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 5", "madza_builder69"),
	        "param_name" => "option_5",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 5"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 name", "madza_builder69"),
            "param_name" => "option_5_name",
            "dependency" => array( 'element' => 'option_5', 'value' => 'On'),
	        "group" => "Option 5"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 5 type", "madza_builder69"),
            "param_name" => "option_5_type",
            "dependency" => array( 'element' => 'option_5', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 5"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 value", "madza_builder69"),
            "param_name" => "option_5_value_slider_value",
            "dependency" => array( 'element' => 'option_5_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 5"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 value from", "madza_builder69"),
            "param_name" => "option_5_value_slider_from",
            "dependency" => array( 'element' => 'option_5_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 5"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 value to", "madza_builder69"),
            "param_name" => "option_5_value_slider_to",
            "dependency" => array( 'element' => 'option_5_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 5"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 value slider step", "madza_builder69"),
            "param_name" => "option_5_value_slider_step",
            "dependency" => array( 'element' => 'option_5_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 5"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 default value", "madza_builder69"),
            "param_name" => "option_5_value_textfield",
            "dependency" => array( 'element' => 'option_5_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 5"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 value", "madza_builder69"),
            "param_name" => "option_5_value_checkbox",
            "dependency" => array( 'element' => 'option_5_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 5"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 5 value from", "madza_builder69"),
                'param_name' => 'option_5_value_select',
                "dependency" => array( 'element' => 'option_5_type', 'value' => 'select'),
				"group" => "Option 5",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_5_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_5_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 5 Mach", "madza_builder69"),
            "param_name" => "option_5_value_mach",
            "dependency" => array( 'element' => 'option_5', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 5"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 5 value size", "madza_builder69"),
            "param_name" => "option_5_value_size",
            "dependency" => array( 'element' => 'option_5', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 5"
        ),
        /* end Select */
		/* end Option 5 */	
		
		
		
		
		
		/* Option 6 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 6", "madza_builder69"),
	        "param_name" => "option_6",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 6"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 name", "madza_builder69"),
            "param_name" => "option_6_name",
            "dependency" => array( 'element' => 'option_6', 'value' => 'On'),
	        "group" => "Option 6"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 6 type", "madza_builder69"),
            "param_name" => "option_6_type",
            "dependency" => array( 'element' => 'option_6', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 6"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 value", "madza_builder69"),
            "param_name" => "option_6_value_slider_value",
            "dependency" => array( 'element' => 'option_6_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 6"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 value from", "madza_builder69"),
            "param_name" => "option_6_value_slider_from",
            "dependency" => array( 'element' => 'option_6_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 6"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 value to", "madza_builder69"),
            "param_name" => "option_6_value_slider_to",
            "dependency" => array( 'element' => 'option_6_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 6"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 value slider step", "madza_builder69"),
            "param_name" => "option_6_value_slider_step",
            "dependency" => array( 'element' => 'option_6_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 6"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 default value", "madza_builder69"),
            "param_name" => "option_6_value_textfield",
            "dependency" => array( 'element' => 'option_6_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 6"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 value", "madza_builder69"),
            "param_name" => "option_6_value_checkbox",
            "dependency" => array( 'element' => 'option_6_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 6"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 6 value from", "madza_builder69"),
                'param_name' => 'option_6_value_select',
                "dependency" => array( 'element' => 'option_6_type', 'value' => 'select'),
				"group" => "Option 6",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_6_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_6_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 6 Mach", "madza_builder69"),
            "param_name" => "option_6_value_mach",
            "dependency" => array( 'element' => 'option_6', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 6"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 6 value size", "madza_builder69"),
            "param_name" => "option_6_value_size",
            "dependency" => array( 'element' => 'option_6', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 6"
        ),
        /* end Select */
		/* end Option 6 */	
		
		
		
		
		/* Option 7 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 7", "madza_builder69"),
	        "param_name" => "option_7",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 7"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 name", "madza_builder69"),
            "param_name" => "option_7_name",
            "dependency" => array( 'element' => 'option_7', 'value' => 'On'),
	        "group" => "Option 7"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 value size", "madza_builder69"),
            "param_name" => "option_7_value_size",
            "dependency" => array( 'element' => 'option_7', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 7"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 value", "madza_builder69"),
            "param_name" => "option_7_value_slider_value",
            "dependency" => array( 'element' => 'option_7_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 7"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 value from", "madza_builder69"),
            "param_name" => "option_7_value_slider_from",
            "dependency" => array( 'element' => 'option_7_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 7"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 value to", "madza_builder69"),
            "param_name" => "option_7_value_slider_to",
            "dependency" => array( 'element' => 'option_7_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 7"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 value slider step", "madza_builder69"),
            "param_name" => "option_7_value_slider_step",
            "dependency" => array( 'element' => 'option_7_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 7"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 default value", "madza_builder69"),
            "param_name" => "option_7_value_textfield",
            "dependency" => array( 'element' => 'option_7_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 7"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 7 value", "madza_builder69"),
            "param_name" => "option_7_value_checkbox",
            "dependency" => array( 'element' => 'option_7_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 7"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 7 value from", "madza_builder69"),
                'param_name' => 'option_7_value_select',
                "dependency" => array( 'element' => 'option_7_type', 'value' => 'select'),
				"group" => "Option 7",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_7_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_7_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 7 type", "madza_builder69"),
            "param_name" => "option_7_type",
            "dependency" => array( 'element' => 'option_7', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 7"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 7 Mach", "madza_builder69"),
            "param_name" => "option_7_value_mach",
            "dependency" => array( 'element' => 'option_7', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 7"
        ),
        /* end Select */
		/* end Option 7 */
		
		
		
		
		/* Option 8 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 8", "madza_builder69"),
	        "param_name" => "option_8",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 8"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 name", "madza_builder69"),
            "param_name" => "option_8_name",
            "dependency" => array( 'element' => 'option_8', 'value' => 'On'),
	        "group" => "Option 8"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 value size", "madza_builder69"),
            "param_name" => "option_8_value_size",
            "dependency" => array( 'element' => 'option_8', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 8"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 value", "madza_builder69"),
            "param_name" => "option_8_value_slider_value",
            "dependency" => array( 'element' => 'option_8_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 8"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 value from", "madza_builder69"),
            "param_name" => "option_8_value_slider_from",
            "dependency" => array( 'element' => 'option_8_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 8"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 value to", "madza_builder69"),
            "param_name" => "option_8_value_slider_to",
            "dependency" => array( 'element' => 'option_8_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 8"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 value slider step", "madza_builder69"),
            "param_name" => "option_8_value_slider_step",
            "dependency" => array( 'element' => 'option_8_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 8"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 default value", "madza_builder69"),
            "param_name" => "option_8_value_textfield",
            "dependency" => array( 'element' => 'option_8_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 8"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 8 value", "madza_builder69"),
            "param_name" => "option_8_value_checkbox",
            "dependency" => array( 'element' => 'option_8_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 8"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 8 value from", "madza_builder69"),
                'param_name' => 'option_8_value_select',
                "dependency" => array( 'element' => 'option_8_type', 'value' => 'select'),
				"group" => "Option 8",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_8_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_8_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 8 type", "madza_builder69"),
            "param_name" => "option_8_type",
            "dependency" => array( 'element' => 'option_8', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 8"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 8 Mach", "madza_builder69"),
            "param_name" => "option_8_value_mach",
            "dependency" => array( 'element' => 'option_8', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 8"
        ),
        /* end Select */
		/* end Option 8 */
		
		
		
		/* Option 9 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 9", "madza_builder69"),
	        "param_name" => "option_9",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 9"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 name", "madza_builder69"),
            "param_name" => "option_9_name",
            "dependency" => array( 'element' => 'option_9', 'value' => 'On'),
	        "group" => "Option 9"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 9 type", "madza_builder69"),
            "param_name" => "option_9_type",
            "dependency" => array( 'element' => 'option_9', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 9"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 value", "madza_builder69"),
            "param_name" => "option_9_value_slider_value",
            "dependency" => array( 'element' => 'option_9_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 9"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 value from", "madza_builder69"),
            "param_name" => "option_9_value_slider_from",
            "dependency" => array( 'element' => 'option_9_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 9"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 value to", "madza_builder69"),
            "param_name" => "option_9_value_slider_to",
            "dependency" => array( 'element' => 'option_9_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 9"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 value slider step", "madza_builder69"),
            "param_name" => "option_9_value_slider_step",
            "dependency" => array( 'element' => 'option_9_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 9"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 default value", "madza_builder69"),
            "param_name" => "option_9_value_textfield",
            "dependency" => array( 'element' => 'option_9_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 9"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 value", "madza_builder69"),
            "param_name" => "option_9_value_checkbox",
            "dependency" => array( 'element' => 'option_9_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 9"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 9 value from", "madza_builder69"),
                'param_name' => 'option_9_value_select',
                "dependency" => array( 'element' => 'option_9_type', 'value' => 'select'),
				"group" => "Option 9",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_9_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_9_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 9 Mach", "madza_builder69"),
            "param_name" => "option_9_value_mach",
            "dependency" => array( 'element' => 'option_9', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 9"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 9 value size", "madza_builder69"),
            "param_name" => "option_9_value_size",
            "dependency" => array( 'element' => 'option_9', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 9"
        ),
        /* end Select */
		/* end Option 9 */
		
		
		
		
		/* Option 10 */
	    array(
	        "type" => "dropdown",
	        "heading" => esc_html__("Option 10", "madza_builder69"),
	        "param_name" => "option_10",
	        "value" => array('Off' => 'Off', 'On' => 'On'),
	        "group" => "Option 10"	
	    ),
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 name", "madza_builder69"),
            "param_name" => "option_10_name",
            "dependency" => array( 'element' => 'option_10', 'value' => 'On'),
	        "group" => "Option 10"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 10 type", "madza_builder69"),
            "param_name" => "option_10_type",
            "dependency" => array( 'element' => 'option_10', 'value' => 'On'),
            "value" => array('none' => 'none', 'slider' => 'slider', 'textfield' => 'textfield', 'select' => 'select', 'checkbox' => 'checkbox'),
	        "group" => "Option 10"
        ),
        /* Slider */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 value", "madza_builder69"),
            "param_name" => "option_10_value_slider_value",
            "dependency" => array( 'element' => 'option_10_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 10"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 value from", "madza_builder69"),
            "param_name" => "option_10_value_slider_from",
            "dependency" => array( 'element' => 'option_10_type', 'value' => 'slider'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 10"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 value to", "madza_builder69"),
            "param_name" => "option_10_value_slider_to",
            "dependency" => array( 'element' => 'option_10_type', 'value' => 'slider'),
            "description" => "Default: 100",
            "value" => "100",
	        "group" => "Option 10"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 value slider step", "madza_builder69"),
            "param_name" => "option_10_value_slider_step",
            "dependency" => array( 'element' => 'option_10_type', 'value' => 'slider'),
            "description" => "Default: 1",
            "value" => "1",
	        "group" => "Option 10"
        ),
        
        /* end Slider */
        /* Textfield */
		array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 default value", "madza_builder69"),
            "param_name" => "option_10_value_textfield",
            "dependency" => array( 'element' => 'option_10_type', 'value' => 'textfield'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 10"
        ),
        /* end Textfield */
        /* Checkbox */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 value", "madza_builder69"),
            "param_name" => "option_10_value_checkbox",
            "dependency" => array( 'element' => 'option_10_type', 'value' => 'checkbox'),
            "description" => "Default: 0",
            "value" => "0",
	        "group" => "Option 10"
        ),
        /* end Checkbox */
        /* Select */
        array(
                'type' => 'param_group',
                'value' => '',
                "heading" => esc_html__("Option 10 value from", "madza_builder69"),
                'param_name' => 'option_10_value_select',
                "dependency" => array( 'element' => 'option_10_type', 'value' => 'select'),
				"group" => "Option 10",
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Title',
                        'param_name' => 'option_10_value_select_title',
                    ),
                    array(
                        'type' => 'textfield',
                        'value' => '',
                        'admin_label' => true,
                        'heading' => 'Value',
                        'param_name' => 'option_10_value_select_value',
                    )
                )
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Option 10 Mach", "madza_builder69"),
            "param_name" => "option_10_value_mach",
            "dependency" => array( 'element' => 'option_10', 'value' => 'On'),
            "value" => array('none' => 'none', 'Plus (+)' => 'plus', 'Multiply (*)' => 'multiply', 'Plus for Multiply (+)' => 'plus_multiply'),
	        "group" => "Option 10"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Option 10 value size", "madza_builder69"),
            "param_name" => "option_10_value_size",
            "dependency" => array( 'element' => 'option_10', 'value' => 'On'),
            "description" => "Default: 1, Sample: If one Door cost 250$ then you need set value size to 250",
            "value" => "1",
	        "group" => "Option 10"
        )
        /* end Select */
		/* end Option 10 */
		
    )
) 
);
}			
	
	

/* Restaurant Menu */

add_shortcode( 'mt_menu', 'mt_menu_func' );
	function mt_menu_func( $atts ) {

        extract(shortcode_atts(array(
            'title' => '',
            'description' => '',
            'price' => '',
        ), $atts));
        

        $output  = '<div class="mt-shortcode-menu">';
	        $output .= '<h6><span class="mt_title">'.$title.'</span><span class="mt_price">'.$price.'</span><span class="clear"></span></h6>';
	        $output .= '<div class="mt_menu_line"></div>';
	        $output .= '<p>'.$description.'</p>';
		$output .= '</div>';
        
    
        return $output;
    }


add_action( 'vc_before_init', 'mt_menu_func_fields' );
function mt_menu_func_fields() {
vc_map( array(
    "base"        => "mt_menu",
    "name"        => esc_html__("Restauran Menu", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "icon-wpb-ui-separator",
    "category" => "Madza Moduls",
    "params"    => array(
	    array(
            "type" => "textfield",
            "heading" => esc_html__("Name", "madza_builder69"),
            "param_name" => "title",
            "value" => "",
            "description" => "Enter staff name"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Description", "madza_builder69"),
            "param_name" => "description",
            "value" => "",
            "description" => "Enter staff education."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Price", "madza_builder69"),
            "param_name" => "price",
            "value" => "",
            "description" => "Enter staff education."
        )
        
    )
) 
);
}			
	
/* 3 COLUMNS */

add_shortcode( 'mt_columns', 'mt_columns_func' );
	function mt_columns_func( $atts ) {
	
	        extract(shortcode_atts(array(
		        'margin_top' => '170',
	            'image1' => '',
	            'image2' => '',
	            'image3' => '',
	            'title1' => '',
	            'title2' => '',
	            'title3' => '',
	            'description1' => '',
	            'description2' => '',
	            'description3' => '',
	            'url1' => '',
	            'url2' => '',
	            'url3' => '',
	            'color_title1' => '#ffffff',
	            'color_title2' => '#ffffff',
	            'color_title3' => '#ffffff',
	            'color_description1' => '#ffffff',
	            'color_description2' => '#ffffff',
	            'color_description3' => '#ffffff',
	            'color_opacity1' => '0.7',
	            'color_opacity2' => '0.7',
	            'color_opacity3' => '0.7',
	            'target' => '_self'
	            
	        ), $atts));
	        
			$attach_image1 = wp_get_attachment_image( $image1, "full");
			$attach_image2 = wp_get_attachment_image( $image2, "full");
			$attach_image3 = wp_get_attachment_image( $image3, "full");
			
			$image_url1 = wp_get_attachment_url( $image1, "full");
			$img1 = aq_resize( $image_url1, 390, 200, true );
			
			$image_url2 = wp_get_attachment_url( $image2, "full");
			$img2 = aq_resize( $image_url2, 390, 200, true );
			
			$image_url3 = wp_get_attachment_url( $image3, "full");
			$img3 = aq_resize( $image_url3, 390, 200, true );
			
			$url1_start = "";
			$url2_start = "";
			$url3_start = "";
			$url1_end = "";
			$url2_end = "";
			$url3_end = "";
			
			if ($url1!=""){ $url1_start = '<a href="'.$url1.'" alt="' . $title1 . '" target="' . $target . '">'; $url1_end = "</a>"; }
			if ($url2!=""){ $url2_start = '<a href="'.$url2.'" alt="' . $title2 . '" target="' . $target . '">'; $url2_end = "</a>"; }
			if ($url3!=""){ $url3_start = '<a href="'.$url3.'" alt="' . $title3 . '" target="' . $target . '">'; $url3_end = "</a>"; }
		
	        $output2 = '';
	        $output2 .= '<div class="mt_sc_column col-md-4">
	        <div class="mt_sc_column_t_1">
	        	' . $url1_start . '
	        	<div class="mt_slide_first mt_sc_text_display">
			        <h3 style="color:' . $color_title1 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title1 . '</h3>
			        <p style="color:' . $color_description1 . '; opacity:'. $color_opacity1 .'; font-size:px!important; line-height:px!important;">' . $description1 . '</p>
			    </div>
			    ' . $url1_end . '' . $url2_start . '
			    <div class="mt_sc_text_display">
			        <h3 style="color:' . $color_title2 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title2 . '</h3>
			        <p style="color:' . $color_description2 . '; opacity:'. $color_opacity3 .'; font-size:px!important; line-height:px!important;">' . $description2 . '</p>
			    </div>
			    ' . $url2_end . '' . $url3_start . '
			    <div class="mt_sc_text_display">
			        <h3 style="color:' . $color_title3 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title3 . '</h3>
			        <p style="color:' . $color_description3 . '; opacity:'. $color_opacity3 .'; font-size:px!important; line-height:px!important;">' . $description3 . '</p>
			    </div>
			    ' . $url3_end . '
		    </div>
	        <div class="mt_sc_column_1"><img class="mt_slide_first" width="390" height="200" src="' . $img1 . '" alt="'. $title1 .'" /><img width="390" height="200" src="' . $img2 . '" alt="'. $title2 .'" /><img width="390" height="200" src="' . $img3 . '" alt="'. $title3 .'" /></div></div>';
	         
	        $output2 .= '<div class="mt_sc_column col-md-4">
	        
	        <div class="mt_sc_column_t_2">
	        	' . $url3_start . '
	         	<div class="mt_slide_first mt_sc_text_display">
			        <h3 style="color:' . $color_title3 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title3 . '</h3>
			        <p style="color:' . $color_description3 . '; opacity:'. $color_opacity3 .'; font-size:px!important; line-height:px!important;">' . $description3 . '</p>
			    </div>
			   ' . $url3_end . ' ' . $url1_start . '
	        	<div class="mt_sc_text_display">
			        <h3 style="color:' . $color_title1 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title1 . '</h3>
			        <p style="color:' . $color_description1 . '; opacity:'. $color_opacity1 .'; font-size:px!important; line-height:px!important;">' . $description1 . '</p>
			    </div>
			    ' . $url1_end . '' . $url2_start . '
			    <div class="mt_sc_text_display">
			        <h3 style="color:' . $color_title2 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title2 . '</h3>
			        <p style="color:' . $color_description2 . '; opacity:'. $color_opacity2 .'; font-size:px!important; line-height:px!important;">' . $description2 . '</p>
			    </div>
			   	' . $url2_end . '	    
			   </div>
	        
	        
	        <div class="mt_sc_column_3"><img width="390" height="200" class="mt_slide_first" src="' . $img3 . '" alt="'. $title3 .'" /><img width="390" height="200" src="' . $img1 . '" alt="'. $title1 .'" /><img  width="390" height="200" src="' . $img2 . '" alt="'. $title2 .'" /></div></div>';
	        

	        $output2 .= '<div class="mt_sc_column col-md-4">
	        
	        <div class="mt_sc_column_t_3">
	        	' . $url2_start . '
			    <div class="mt_slide_first mt_sc_text_display">
			        <h3 style="color:' . $color_title2 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title2 . '</h3>
			        <p style="color:' . $color_description2 . '; opacity:'. $color_opacity2 .'; font-size:px!important; line-height:px!important;">' . $description2 . '</p>
			    </div>
			    ' . $url2_end . '' . $url3_start . '
			    <div class="mt_sc_text_display">
			        <h3 style="color:' . $color_title3 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title3 . '</h3>
			        <p style="color:' . $color_description3 . '; opacity:'. $color_opacity3 .'; font-size:px!important; line-height:px!important;">' . $description3 . '</p>
			    </div>
			    ' . $url3_end . ' ' . $url1_start . '
			    <div class="mt_sc_text_display">
			        <h3 style="color:' . $color_title1 . '; font-weight:bold!important;  font-size:18px!important; line-height:px!important;">' . $title1 . '</h3>
			        <p style="color:' . $color_description1 . '; opacity:'. $color_opacity1 .'; font-size:px!important; line-height:px!important;">' . $description1 . '</p>
			    </div>
			    ' . $url1_end . '
		    </div>
	        
	        
	        <div class="mt_sc_column_2"><img width="390" height="200" class="mt_slide_first" src="' . $img2 . '" alt="'. $title2 .'" /><img width="390" height="200" src="' . $img3 . '" alt="'. $title3 .'" /><img width="390" height="200" src="' . $img1 . '" alt="'. $title1 .'" /></div></div>';
	       	    
	        return '<div style="margin-top:-'.$margin_top.'px" class="mt_column_module"><div class="row">'.$output2.'</div></div>';
	    }
	


add_action( 'vc_before_init', 'mt_columns_func_fields' );
function mt_columns_func_fields() {
vc_map( array(
    "base"        => "mt_columns",
    "name"        => esc_html__("3 Column Animation", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "mt_module_3_columns",
    "category" => "Madza Moduls",
    "params"    => array(
	    array(
            "type" => "attach_image",
            "heading" => esc_html__("Image 1", "madza_builder69"),
            "param_name" => "image1",
            "value" => "",
            "description" => "Enter image."
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Title 1", "madza_builder69"),
            "param_name" => "title1",
            "value" => "",
            "description" => ""
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Description 1", "madza_builder69"),
            "param_name" => "description1",
            "value" => "",
            "description" => ""
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Link 1", "madza_builder69"),
            "param_name" => "url1",
            "value" => "",
            "description" => "Sample: http://www.yourlink.com"
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__("Image 2", "madza_builder69"),
            "param_name" => "image2",
            "value" => "",
            "description" => "Enter image."
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Title 2", "madza_builder69"),
            "param_name" => "title2",
            "value" => "",
            "description" => ""
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Description 2", "madza_builder69"),
            "param_name" => "description2",
            "value" => "",
            "description" => ""
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link 2", "madza_builder69"),
            "param_name" => "url2",
            "value" => "",
            "description" => "Sample: http://www.yourlink.com"
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__("Image 3", "madza_builder69"),
            "param_name" => "image3",
            "value" => "",
            "description" => "Enter image."
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Title 3", "madza_builder69"),
            "param_name" => "title3",
            "value" => "",
            "description" => ""
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Description 3", "madza_builder69"),
            "param_name" => "description3",
            "value" => "",
            "description" => ""
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link 3", "madza_builder69"),
            "param_name" => "url3",
            "value" => "",
            "description" => "Sample: http://www.yourlink.com"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Title 1 Color", "madza_builder69"),
            "param_name" => "color_title1",
            "value" => "",
            "description" => "Select title color",
            "group" => "Style"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Title 2 Color", "madza_builder69"),
            "param_name" => "color_title2",
            "value" => "",
            "description" => "Select title color",
            "group" => "Style"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Title 3 Color", "madza_builder69"),
            "param_name" => "color_title3",
            "value" => "",
            "description" => "Select title color",
            "group" => "Style"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Description 1 Color", "madza_builder69"),
            "param_name" => "color_description1",
            "value" => "",
            "description" => "Select description color",
            "group" => "Style"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Description 2 Color", "madza_builder69"),
            "param_name" => "color_description2",
            "value" => "",
            "description" => "Select description color",
            "group" => "Style"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Description 3 Color", "madza_builder69"),
            "param_name" => "color_description3",
            "value" => "",
            "description" => "Select description color",
            "group" => "Style"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Description 1 Opacity", "madza_builder69"),
            "param_name" => "color_opacity1",
            "value" => array('0.7' => '0.7', '0.8' => '0.8', '0.9' => '0.9', '1.0' => '1.0', '0.6' => '0.6', '0.5' => '0.5', '0.4' => '0.4', '0.3' => '0.3'),
            "description" => "Select description opacity",
            "group" => "Style"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Description 2 Opacity", "madza_builder69"),
            "param_name" => "color_opacity2",
            "value" => array('0.7' => '0.7', '0.8' => '0.8', '0.9' => '0.9', '1.0' => '1.0', '0.6' => '0.6', '0.5' => '0.5', '0.4' => '0.4', '0.3' => '0.3'),
            "description" => "Select description opacity",
            "group" => "Style"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Description 3 Opacity", "madza_builder69"),
            "param_name" => "color_opacity3y ",
            "value" => array('0.7' => '0.7', '0.8' => '0.8', '0.9' => '0.9', '1.0' => '1.0', '0.6' => '0.6', '0.5' => '0.5', '0.4' => '0.4', '0.3' => '0.3'),
            "description" => "Select description opacity",
            "group" => "Style"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin to Top", "madza_builder69"),
            "param_name" => "margin_top",
            "value" => "",
            "description" => "Default: 170",
             "group" => "Style"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Link Target", "madza_builder69"),
            "param_name" => "target",
            "value" => array('_self' => 'Default: _self', '_parent' => '_parent', '_blank' => '_blank', '_top' => '_top'),
            "description" => "Opens the link in a same frame as it was clicked or new window or tab",
            "group" => "Style"
        ),

        
    )
) 
);	}


/* Posts */

add_shortcode( 'mt_posts', 'mt_posts_func' );
	function mt_posts_func( $atts ) {

        extract(shortcode_atts(array(
            'posttype' => '',
            'item_nr' => '',
            'sorting' => '',
            'sortingby' => '',
            'include' => '',
            'exclude' => '',
            'box_colors' => '',
            'category' => '',
            'class' => '',
            'type' => '',
            'title_colors' => '',
            'contrast' => '',
        ), $atts));

		global $exclude_single_id, $post;
        if (is_single()) { $exclude = $exclude_single_id; }
		
		$myposts = get_posts('post_type='. $posttype .'&order='. $sorting .'&orderby='. $sortingby .'&include='. $include .'&exclude='. $exclude .'&posts_per_page='.$item_nr.'&'.$posttype.'_cat='.$category);
		$mt_posts = '';
		if($type=="small" or $type==""){
			foreach($myposts as $post){
				setup_postdata($post);
				$excerpt = get_the_excerpt(); 
				
				$image = get_post_thumbnail_id();
				$image_url = wp_get_attachment_url( $image, "full");
				$img = aq_resize( $image_url, 75, 65, true );
				
				$mt_posts .='<div class="'.$class.' mt_sc_post_in">';
					$mt_posts .='<div class="mt_sc_post_img"><a href="'. get_permalink().'"><img src="'. $img .'" alt="'. get_the_title() .'" /></a></div>';
					$mt_posts .='<div class="mt_sc_post_text">'; 
						$mt_posts .='<a class="mt_sc_post_link" href="'. get_permalink().'">'. get_the_title() .'</a>';
						$mt_posts .='<p class="mt_sc_post_date">'. esc_attr( get_the_date() ) .'</p>';
					$mt_posts .= '</div>';		
					$mt_posts .='<div class="clear"></div>';
				$mt_posts .= '</div>';
			}
    	}	
    	
    	if($type=="small2"){
	    	$mt_posts .='<div class="row">';
			foreach($myposts as $post){
				setup_postdata($post);
				$excerpt = get_the_excerpt(); 
				$excerpts = substr($excerpt, 0, 50);
				
				$image = get_post_thumbnail_id();
				$image_url = wp_get_attachment_url( $image, "full");
				$img = aq_resize( $image_url, 100, 100, true );
				
				$mt_posts .='<div class="'.$class.' col-md-4"><a href="'. get_permalink().'"><div class="mt_sc_post_in_2">';
					$mt_posts .='<div class="mt_sc_post_img_2"><img src="'. $img .'" alt="'. get_the_title() .'" /></div>';
					$mt_posts .='<div class="mt_sc_post_text_2">'; 
						$mt_posts .='<div class="mt_sc_post_link_2">'. get_the_title() .'</div>';
						$mt_posts .='<p class="mt_sc_post_date_2">'. $excerpts .'...</p>';
					$mt_posts .= '</div>';		
					$mt_posts .='<div class="clear"></div>';
				$mt_posts .= '</div></a></div>';
			}
			$mt_posts .='</div>';
    	}	
    	
    	if($type=="small3"){
	    	$mt_posts .='<div class="row">';
			foreach($myposts as $post){
				setup_postdata($post);
				$excerpt = get_the_excerpt(); 
				$excerpts = substr($excerpt, 0, 70);
				
				$image = get_post_thumbnail_id();
				$image_url = wp_get_attachment_url( $image, "full");
				$img = aq_resize( $image_url, 100, 180, true );
			
				
				$mt_posts .='<div class="'.$class.' col-md-6"><a href="'. get_permalink().'"><div class="mt_sc_post_in_2">';
					$mt_posts .='<div class="mt_sc_post_img_2"><img src="'. $img .'" alt="'. get_the_title() .'" /></div>';
					$mt_posts .='<div class="mt_sc_post_text_2">'; 
						$mt_posts .='<div class="mt_sc_post_link_2">'. get_the_title() .'</div>';
						$mt_posts .='<p class="mt_sc_post_date_2">'. $excerpts .'...</p>';
					$mt_posts .= '</div>';		
				$mt_posts .= '</div></a></div>';
			}
			$mt_posts .='</div>';
    	}	
    	
    	if($type=="midle"){
	    	$mt_posts .='<div class="row mt_sc_post_midle">';
			foreach($myposts as $post){
				setup_postdata($post);
				$excerpt = get_the_excerpt(); 
				$excerpts = substr($excerpt, 0, 60);
				
				$image = get_post_thumbnail_id();
				$image_url = wp_get_attachment_url( $image, "full");
				$img = aq_resize( $image_url, 360, 180, true );
				
				$mt_posts .='<div class="'.$class.' col-md-4"><a href="'. get_permalink().'"><div class="mt_sc_post_in">';
				
					$mt_posts .='<div class="mt_sc_post_img"><img  width="360" height="180"  src="'. $img .'" alt="'. get_the_title() .'" /></div>';	
					$mt_posts .='<div class="mt_sc_post_text" style="background: '.$box_colors.';">'; 
						$mt_posts .='<div class="mt_sc_post_link" style="color:'. $title_colors .'">'. get_the_title() .'</div>';
						$mt_posts .='<p class="mt_sc_post_date">'. $excerpts .' . . .</p>';
					$mt_posts .= '</div>';	
				$mt_posts .= '</div></a></div>';
			}
			$mt_posts .='</div>';
    	}	
    	
    	if($type=="normal"){
	    	$mt_posts .='<div class="row">';
			foreach($myposts as $post){
				setup_postdata($post);
				$excerpt = get_the_excerpt(); 
				
				$image = get_post_thumbnail_id();
				$image_url = wp_get_attachment_url( $image, "full");
				$img = aq_resize( $image_url, 360, 240, true );
				
				$mt_posts .='<div class="'.$class.' col-md-4 mt_sc_post_in_n">';
					$mt_posts .='<div class="mt_sc_post_img_n"><a href="'. get_permalink().'"><img src="'. $img .'" alt="'. get_the_title() .'" /><p class="mt_sc_post_date_n">'. esc_attr( get_the_date() ) .'</p></a></div>';
					$mt_posts .='<div class="mt_sc_post_text_n">'; 
						$mt_posts .='<a class="mt_sc_post_link_n" href="'. get_permalink().'">'. get_the_title() .'</a>';
					$mt_posts .= '</div>';		
				$mt_posts .= '</div>';
			}
			$mt_posts .='</div>';
    	}
    	
    	if($type=="big"){
	    	$mt_posts .='<div class="row">';
			foreach($myposts as $post){
				setup_postdata($post);
				$excerpt = get_the_excerpt(); 
				$excerpts = substr($excerpt, 0, 120);
				
				$image = get_post_thumbnail_id();
				$image_url = wp_get_attachment_url( $image, "full");
				$img = aq_resize( $image_url, 360, 360, true );
	        
				$mt_posts .='<div class="'.$class.' col-md-4 mt_sc_post_in_b">';
					$mt_posts .='<div class="mt_sc_post_img_b"><a href="'. get_permalink().'"><img  width="360" height="360" src="'. $img .'" alt="'. get_the_title() .'" /><p class="mt_sc_post_date_b"><span>'. esc_attr( get_the_date() ) .'</span></p></a></div>';
					$mt_posts .='<div class="mt_sc_post_text_b">'; 
						$mt_posts .='<a class="mt_sc_post_link_b" href="'. get_permalink().'"><h6>'. get_the_title() .'</h6></a>';
						$mt_posts .='<p>'. $excerpts .'...</p>';
					$mt_posts .= '</div>';		
				$mt_posts .= '</div>';
			}
			$mt_posts .='</div>';
    	}
    	
    	wp_reset_query();
		return '<div class="mt_sc_post '. $contrast .'">'.$mt_posts.'</div>'; 
		
        $output = $this->startRow($el_position) . $output . $this->endRow($el_position);
        return  $output;
    }
    
    add_action( 'vc_before_init', 'mt_posts_fields' );
	function mt_posts_fields() {
	vc_map( array(
	    "base"        => "mt_posts",
	    "name"        => esc_html__("Post", "madza_builder69"),
	    "class"        => "mb_composer_spacer",
	    "icon"      => "",
    "category" => "Madza Moduls",
	    "params"    => array(
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Custom Post Type", "madza_builder69"),
	            "param_name" => "posttype",
	            "value" => "",
	            "description" => esc_html__("Set Custom Post Type. Sample: portfolio, post, causes, our-staff, our-services", "madza_builder69")
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Type", "madza_builder69"),
	            "param_name" => "type",
	            "value" => array('Extra Small' => 'small', 'Small 3 Columns' => 'small2', 'Small 2 Columns' => 'small3', 'Midle 3 Columns' => 'midle', 'Normal' => 'normal', 'Big' => 'big'),
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Show Items", "madza_builder69"),
	            "param_name" => "item_nr",
	            "value" => array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Show only category", "madza_builder69"),
	            "param_name" => "category",
	            "value" => "",
	            "description" => esc_html__("Set category slug.", "madza_builder69")
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Sorting", "madza_builder69"),
	            "param_name" => "sorting",
	            "value" => array('DESC' => 'DESC', 'ASC' => 'ASC'),
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Sorting By", "madza_builder69"),
	            "param_name" => "sortingby",
	            "value" => array('none' => 'none', 'Order by ID' => 'ID', 'Order by author' => 'author', 'Order by title' => 'title', 'Order by date' => 'date', 'Order by last modified date' => 'modified', 'Order by post/page parent id' => 'parent', 'Random order' => 'rand', 'Order by number of comments' => 'comment_count'),
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Include", "madza_builder69"),
	            "param_name" => "include",
	            "description" => esc_html__("Include post ID, Sample: 34, 2, 12", "madza_builder69"),
	            "value" => "",
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Exclude", "madza_builder69"),
	            "param_name" => "exclude",
	            "description" => esc_html__("Exclude post ID, Sample: 14, 12, 32", "madza_builder69"),
	            "value" => "",
	        ),
	        
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Text Color", "madza_builder69"),
	            "param_name" => "contrast",
	            "value" => array('Dark' => 'mt_c_dark', 'Light' => 'mt_c_light'),
	        ),
	        array(
	            "type" => "colorpicker",
	            "heading" => esc_html__("Box Color", "madza_builder69"),
	            "param_name" => "box_colors",
	            "value" => "",
	        ),
	        array(
	            "type" => "colorpicker",
	            "heading" => esc_html__("Title Color for middle style", "madza_builder69"),
	            "param_name" => "title_colors",
	            "value" => "",
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("class", "madza_builder69"),
	            "param_name" => "class",
	            "value" => ""
	        ),
	        
	        
	    )
	) );
	
	}





/* Image */

add_shortcode( 'mt_image', 'mt_image_func' );
	function mt_image_func( $atts ) {
	
	        extract(shortcode_atts(array(
	            'title' => '',
	            'description' => '',
	            'hstyle' => '',
	            'tstyle' => '',
	            'color' => '',
	            'image' => '',
	            'size' => '',
	            'text_color' => '',
	            'fstyle' => '',
	            'border_size' => '',
	            'border_color' => '',
	            'url' => '',
	            'size_w' => '600',
	            'size_h' => '600',
	        ), $atts));
	        
	        $image_url = wp_get_attachment_url( $image, "full");
	        $image_1 = aq_resize( $image_url, 430, 600, true );
	        $image_2 = aq_resize( $image_url, 600, 430, true );
	        $image_3 = aq_resize( $image_url, 600, 600, true );
	        $image_4 = aq_resize( $image_url, 600, 300, true );
	        $image_5 = aq_resize( $image_url, 300, 600, true );
	        $image_custom = aq_resize( $image_url, $size_w, $size_h, true );
			$attach_image = $image_1;
			if($size=="staff_size_2"){ $attach_image = $image_2; }
			if($size=="staff_size_3"){ $attach_image = $image_3; }
			if($size=="staff_size_4"){ $attach_image = $image_4; }
			if($size=="staff_size_5"){ $attach_image = $image_5; }
			if($size=="staff_size_customize"){ $attach_image = $image_custom; }
			
			if ( $title_area!="" ) { $title_area = '<h6>' . $title . '</h6>';   } else { $$title_area=""; }
			if ( $url!="" ) { $a1 = '<a href="' . $url . '">'; $a2="</a>";  } else { $a1="";  $a2="";}
			if ( $description!="" ) { $seperator = '<div class="mt-shortcode-separator default"></div>'; } else { $seperator=""; }
			if ( $description!="" ) { $description_ = '<p>' . $description . '</p>'; } else { $description_=""; }
	
	        $output  = $a1.'<div class="mt-shortcode-image ' . $hstyle . ' ' . $tstyle . ' ' . $fstyle . ' ' . $text_color . '" style="border-color:' . $border_color . '; border-width:' . $border_size . 'px; ">';
		        $output .= '<div class="mt-shortcode-image-hover" ><div class="image-inside" style="background-color:' . $color . '; border-color:' . $color . ';"><div class="image-inside-in">';
			        $output .= '<div class="mt-shortcode-image-content" style="border-color:' . $color . ';">';
			        $output .= $title_area;
			        $output .= $seperator;
			        $output .= $description_.'</div>';
		        $output .= '</div></div></div>';
		        $output .= '<img src="' . $attach_image . '" alt="' . $title . '" />';
	        $output .= '</div>'.$a2;
	        
	    
	        return $output;
	    }
	


add_action( 'vc_before_init', 'mt_image_func_fields' );
function mt_image_func_fields() {
vc_map( array(
    "base"        => "mt_image",
    "name"        => esc_html__("Image Frame", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "icon-wpb-single-image",
    "category" => "Madza Moduls",
    "params"    => array(
	    array(
            "type" => "textfield",
            "heading" => esc_html__("Title", "madza_builder69"),
            "param_name" => "title",
            "value" => "",
            "description" => "Enter image title"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Description", "madza_builder69"),
            "param_name" => "description",
            "value" => "",
            "description" => "Enter image description."
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__("Image", "madza_builder69"),
            "param_name" => "image",
            "value" => "",
            "description" => "Enter image."
        ),
    	array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", "madza_builder69"),
            "param_name" => "color",
            "value" => "#444444",
            "description" => "Select hover background color, default: #444444"
        ),
         array(
            "type" => "textfield",
            "heading" => esc_html__("Border size (px)", "madza_builder69"),
            "param_name" => "border_size",
            "value" => "",
            "description" => "Enter image description.",
            "group" => "Style"
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Border Color", "madza_builder69"),
            "param_name" => "border_color",
            "value" => "",
            "description" => "Select border color",
            "group" => "Style"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Hover Style", "madza_builder69"),
            "param_name" => "hstyle",
            "value" => array( 'Style 1' => 'style_1', 'Style 2' => 'style_2', 'Style 3' => 'style_3', 'Style 4' => 'style_4', 'Style 5' => 'style_5', 'Style 6' => 'style_6', 'Style 7' => 'style_7', 'Style 8' => 'style_8'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Position Style", "madza_builder69"),
            "param_name" => "tstyle",
            "value" => array( 'Top Left' => 'type_1', 'Center' => 'type_2', 'Bottom Left' => 'type_3', 'Center / Seperator Off' => 'type_4'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Typography Style", "madza_builder69"),
            "param_name" => "fstyle",
            "value" => array( 'Style 1' => 'font_1', 'Style 2' => 'font_2', 'Style 3' => 'font_3'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Image Size", "madza_builder69"),
            "param_name" => "size",
            "value" => array('3:4' => 'staff_size_1', '4:3' => 'staff_size_2', '1:1' => 'staff_size_3', '2:1' => 'staff_size_4', '1:2' => 'staff_size_5', 'Custom Size' => 'staff_size_customize'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Image Width(px)", "madza_builder69"),
            "param_name" => "size_w",
             "dependency" => array( 'element' => 'size', 'value' => 'staff_size_customize'),
            "value" => "",
            "description" => "Default: 555"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Image Height(px)", "madza_builder69"),
            "param_name" => "size_h",
             "dependency" => array( 'element' => 'size', 'value' => 'staff_size_customize'),
            "value" => "",
            "description" => "Default: 555"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Text Color", "madza_builder69"),
            "param_name" => "text_color",
            "value" => array( 'Default' => 'default', 'Light' => 'text_color_light', 'Dark' => 'text_color_dark'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("URL", "madza_builder69"),
            "param_name" => "url",
            "value" => "",
            "description" => "http://www.yourlink.com"
        )

        
    )
) 
);	
}
	
/* Staff */

add_shortcode( 'mt_staff', 'mt_staff_func' );
	function mt_staff_func( $atts ) {

        extract(shortcode_atts(array(
            'title' => '',
            'description' => '',
            'hstyle' => '',
            'tstyle' => '',
            'color' => '',
            'image' => '',
            'size' => '',
            'instagram' => '',
            'googleplus' => '',
            'facebook' => '',
            'twitter' => '',
            'text_color' => '',
            'size_w' => '600',
	        'size_h' => '600',
        ), $atts));
        
		 $image_url = wp_get_attachment_url( $image, "full");
	        $image_1 = aq_resize( $image_url, 430, 600, true );
	        $image_2 = aq_resize( $image_url, 600, 430, true );
	        $image_3 = aq_resize( $image_url, 600, 600, true );
	        $image_4 = aq_resize( $image_url, 600, 300, true );
	        $image_5 = aq_resize( $image_url, 300, 600, true );
	        $image_custom = aq_resize( $image_url, $size_w, $size_h, true );
			$attach_image = $image_1;
			$mt_width = "430"; $mt_height = "600";
			if($size=="staff_size_2"){ $attach_image = $image_2; $mt_width = "600"; $mt_height = "430";}
			if($size=="staff_size_3"){ $attach_image = $image_3; $mt_width = "600"; $mt_height = "600";}
			if($size=="staff_size_4"){ $attach_image = $image_4; $mt_width = "600"; $mt_height = "300";}
			if($size=="staff_size_5"){ $attach_image = $image_5; $mt_width = "300"; $mt_height = "600";}
			if($size=="staff_size_customize"){ $attach_image = $image_custom; $mt_width = $size_w; $mt_height = $size_h;}
		
		if($facebook!="") { $link_1 = "<li><a href='".$facebook."'><i class='fa fa-facebook'></i></a></li>"; } else { $link_1 = ""; }
		if($twitter!="") { $link_2 = "<li><a href='".$twitter."'><i class='fa fa-twitter'></i></a></li>"; } else { $link_2 = ""; }
		if($googleplus!="") { $link_3 = "<li><a href='".$googleplus."'><i class='fa fa-google-plus'></i></a></li>"; } else { $link_3 = ""; }
		if($instagram!="") { $link_4 = "<li><a href='".$instagram."'><i class='fa fa-instagram'></i></a></li>"; } else { $link_4 = ""; }

        $output  = '<div class="mt-shortcode-staff ' . $hstyle . ' ' . $tstyle . ' ' . $text_color . '" >';
	        $output .= '<div class="mt-shortcode-staff-hover" style="background-color:' . $color . ';"><div class="staff-inside"><div class="staff-inside-in">';
		        $output .= '<div class="mt-shortcode-staff-content"><h6>' . $title . '</h6>';
		        $output .= '<div class="mt-shortcode-separator default"></div>';
		        $output .= '<p>' . $description . '</p></div>';
		        $output .= '<ul>' . $link_1 . '' . $link_2 . '' . $link_3 . '' . $link_4 . '</ul>';
	        $output .= '</div></div></div>';
	        $output .= '<img width="' . $mt_width . '" height="' . $mt_height . '" src="' . $attach_image . '" alt="' . $title . '" />';
        $output .= '</div>';
        
    
        return $output;
    }


add_action( 'vc_before_init', 'mt_mt_staff_fields' );
function mt_mt_staff_fields() {
vc_map( array(
    "base"        => "mt_staff",
    "name"        => esc_html__("Staff", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "icon-wpb-single-image",
    "category" => "Madza Moduls",
    "params"    => array(
	    array(
            "type" => "textfield",
            "heading" => esc_html__("Name", "madza_builder69"),
            "param_name" => "title",
            "value" => "",
            "description" => "Enter staff name"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Education", "madza_builder69"),
            "param_name" => "description",
            "value" => "",
            "description" => "Enter staff education."
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__("Image", "madza_builder69"),
            "param_name" => "image",
            "value" => "",
            "description" => "Enter Staff Image."
        ),
    	array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", "madza_builder69"),
            "param_name" => "color",
            "value" => "#444444",
            "description" => "Select hover background color, default: #444444"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Hover Style", "madza_builder69"),
            "param_name" => "hstyle",
            "value" => array( 'Style 1' => 'style_1', 'Style 2' => 'style_2', 'Style 3' => 'style_3'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Typography Style", "madza_builder69"),
            "param_name" => "tstyle",
            "value" => array( 'Style 1' => 'type_1', 'Style 2' => 'type_2', 'Style 3' => 'type_3'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Image Size", "madza_builder69"),
            "param_name" => "size",
            "value" => array( '3:4' => 'staff_size_1', '4:3' => 'staff_size_2', '1:1' => 'staff_size_3', '2:1' => 'staff_size_4', '1:2' => 'staff_size_5', 'Custom Size' => 'staff_size_customize'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Image Width(px)", "madza_builder69"),
            "param_name" => "size_w",
            "dependency" => array( 'element' => 'size', 'value' => 'staff_size_customize'),
            "value" => "",
            "description" => "Default: 555"
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Image Height(px)", "madza_builder69"),
            "param_name" => "size_h",
             "dependency" => array( 'element' => 'size', 'value' => 'staff_size_customize'),
            "value" => "",
            "description" => "Default: 555"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Text Color", "madza_builder69"),
            "param_name" => "text_color",
            "value" => array( 'Default' => 'default', 'Light' => 'text_color_light', 'Dark' => 'text_color_dark'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Facebook URL", "madza_builder69"),
            "param_name" => "facebook",
            "value" => "",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Twitter URL", "madza_builder69"),
            "param_name" => "twitter",
            "value" => "",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("GooglePlus URL", "madza_builder69"),
            "param_name" => "googleplus",
            "value" => "",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Instagram URL", "madza_builder69"),
            "param_name" => "instagram",
            "value" => "",
        )

        
    )
) 
);
}
	


add_shortcode( 'mt_icon_text', 'mt_icon_text_func' );
	function mt_icon_text_func( $atts ) {

        extract(shortcode_atts(array(
            'style_text' => '',
            'style_hover' => '',
            'style_icon' => '',
            'color_title' => '',
            'color_icon' => '',
            'color_icon_bg' => '',
            'color_icon_border' => '',
            'icon' => '',
            'text' => '',
            'title' => '',
            'color_text' => '',
            'seperator' => '',
            'size_icon' => '',
            'size_icon_h' => '',
            'size_text' => '',
            'size_text_h' => '',
            'size_title' => '',
            'size_title_h' => '',
            'icon_bottom' => '',
            'icon_type' => '',
            'image_icon' => '',
            'bold' => '',
            'size_icon_bs' => '',
            'size_icon_bp' => '',
        ), $atts));
		$attach_image = wp_get_attachment_image_src( $image_icon, "full");
		if ( $seperator=="1" ) { $seperator_ = '<div class="mt-shortcode-separator default"></div>'; } else { $seperator_=""; }
		
		if($text!="") { $text_='<p style="color:' . $color_text . '; font-size:' . $size_text . 'px!important; line-height:' . $size_text_h . 'px!important;">' . $text . '</p>'; } else { $text_=""; }
		
		if ( $title !="" ) { $h3 = '<h3 style="color:' . $color_title . '; font-weight:' . $bold . '!important;  font-size:' . $size_title . 'px!important; line-height:' . $size_title_h . 'px!important;">' . $title . '</h3>'; } else { $h3 = "";}
		
		if ( $icon_type=="mt_icon_image" ) { $icon_s = '<img src="'.$attach_image[0].'" style="padding:'. $size_icon_bp . 'px!important; width:' . $size_icon . 'px!important; line-height:' . $size_icon_h . 'px!important; background-color:' . $color_icon_bg . '; color:' . $color_icon . '; border-width:' . $size_icon_bs . 'px;  border-color:' . $color_icon_border . '; margin-bottom:' . $icon_bottom . 'px;"  />'; } else { $icon_s = '<i class="' . $icon . '" style="padding:'. $size_icon_bp . 'px!important; font-size:' . $size_icon . 'px!important; line-height:' . $size_icon_h . 'px!important; background-color:' . $color_icon_bg . '; color:' . $color_icon . '; border-width:' . $size_icon_bs . 'px;  border-color:' . $color_icon_border . '; margin-bottom:' . $icon_bottom . 'px;"></i>'; }
		
		
        $output  = '<div class="mt-shortcode-icon-text ' . $style_text . ' ' . $style_hover . ' ' . $style_icon . '">';
        $output .= $icon_s;
        $output .= $h3;
        $output .= $seperator_;
        $output .= $text_;
        $output .= '</div>';
        
    
        return $output;
    }


add_action( 'vc_before_init', 'mt_mt_icon_text_fields' );
function mt_mt_icon_text_fields() {
vc_map( array(
    "base"        => "mt_icon_text",
    "name"        => esc_html__("Icon Text", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "icon-wpb-toggle-small-expand",
    "category" => "Madza Moduls",
    "params"    => array(
    	array(
            "type" => "textfield",
            "heading" => esc_html__("Title", "madza_builder69"),
            "param_name" => "title",
            "value" => ""
            
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__("Text", "madza_builder69"),
            "param_name" => "text",
            "value" => ""
            
        ),
         array(
            "type" => "dropdown",
            "heading" => esc_html__("Icon Type", "madza_builder69"),
            "param_name" => "icon_type",
            "value" => array('Font Icon' => 'mt_icon_font', 'Image Icon' => 'mt_icon_image' ),
            "description" => "Select icon type."
        ),
        array(
            "type" => "icon_manager",
            "heading" => esc_html__("Font Icon", "madza_builder69"),
            "param_name" => "icon",
            "dependency" => array( 'element' => 'icon_type', 'value' => 'mt_icon_font'),
            "value" => "",
            
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__("Image Icon", "madza_builder69"),
            "param_name" => "image_icon",
             "dependency" => array( 'element' => 'icon_type', 'value' => 'mt_icon_image'),
            "value" => "",
            "description" => "Insert Image icon."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Text Style", "madza_builder69"),
            "param_name" => "style_text",
            "value" => array('Icon Top Left' => 'mt_text_style_3', 'Icon Top Center' => 'mt_text_style_2' ,  'Icon Left' => 'mt_text_style_1' ,  'Icon Right' => 'mt_text_style_4','Icon Top Right' => 'mt_text_style_5', ),
            "description" => "Select style."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Icon Style", "madza_builder69"),
            "param_name" => "style_icon",
            "value" => array('Normal Icon' => 'mt_icon_style_3', 'Quad Icon' => 'mt_icon_style_2', 'Circle Icon' => 'mt_icon_style_1'  ),
            "description" => "Select style."
        ),
        
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color for Icon", "madza_builder69"),
            "param_name" => "color_icon",
            "value" => "",
            "description" => "Select text color for icon.",
            "group" => "Style"	
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color for Icon Background", "madza_builder69"),
            "param_name" => "color_icon_bg",
            "value" => "",
            "description" => "Select icon background color.",
            "group" => "Style"	
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color for Icon Border", "madza_builder69"),
            "param_name" => "color_icon_border",
            "value" => "",
            "description" => "Select icon border color.",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Icon Size (px)", "madza_builder69"),
            "param_name" => "size_icon",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Icon line-height (em)", "madza_builder69"),
            "param_name" => "size_icon_h",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Icon Bottom Space (px)", "madza_builder69"),
            "param_name" => "icon_bottom",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Icon Border Size (px)", "madza_builder69"),
            "param_name" => "size_icon_bs",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Icon Border Padding (px)", "madza_builder69"),
            "param_name" => "size_icon_bp",
            "group" => "Style"	
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color for Title", "madza_builder69"),
            "param_name" => "color_title",
            "value" => "",
            "description" => "Select text color for title.",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title Size (px)", "madza_builder69"),
            "param_name" => "size_title",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title line-height (px)", "madza_builder69"),
            "param_name" => "size_title_h",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title font-weight", "madza_builder69"),
            "param_name" => "bold",
            "group" => "Style"	
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color for text", "madza_builder69"),
            "param_name" => "color_text",
            "value" => "",
            "description" => "Select text color.",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Text Size (px)", "madza_builder69"),
            "param_name" => "size_text",
            "group" => "Style"	
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Text line-height (px)", "madza_builder69"),
            "param_name" => "size_text_h",
            "group" => "Style"	
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Icon Hover", "madza_builder69"),
            "param_name" => "style_hover",
            "value" => array('On' => 'mt-icon-hover', 'Off' => 'mt-icon-hover-off'),
            "description" => "Turn on/off icon hover effect.",
            "group" => "Style"	
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Seperator", "madza_builder69"),
            "param_name" => "seperator",
            "value" => array('Off' => '2', 'On' => '1' ),
            "description" => "Turn on/off seperator."
        ),
        

        
    )
) 
);
}



/* SEPARATOR */

add_shortcode( 'mt_separator', 'mt_separator_func' );
	function mt_separator_func( $atts ) {

        extract(shortcode_atts(array(
            'space_count' => '',
            'size' => 'default',
            'position' => 'left',
            'color' => '',
            'height' => '',
            'width' => '',
            'image' => '',
            'margin_top' => '',
            'margin_bottom' => ''
        ), $atts));


        $output  = '<div class="mt-shortcode-separator ' . $size . ' ' . $position . '" style="height:' . $height . '; width:' . $width . '; background-color:' . $color . ';margin-top:' . $margin_top . '; margin-bottom:' . $margin_bottom . '">';
        $output .= '</div><div class="clear"></div>';
        
    
        return $output;
    }

add_action( 'vc_before_init', 'mt_mt_separator_fields' );
function mt_mt_separator_fields() {
vc_map( array(
    "base"        => "mt_separator",
    "name"        => esc_html__("Separator", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "icon-wpb-ui-separator",
    "category" => "Madza Moduls",
    "params"    => array(
    	array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", "madza_builder69"),
            "param_name" => "color",
            "value" => "#444444",
            "description" => "Select separator color, default: #444444"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Size", "madza_builder69"),
            "param_name" => "size",
            "value" => array(  'Settings from Customizer' => 'default', 'Full' => 'full',  'Small' => 'small'),
            "description" => "Select separator size."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Position", "madza_builder69"),
            "param_name" => "position",
            "value" => array( 'Left' => 'left', 'Center' => 'center', 'Right' => 'right'),
            "description" => "Select separator position."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin Top", "madza_builder69"),
            "param_name" => "margin_top",
            "value" => "",
            "description" => "Enter top margin size."
        ),
        
        array(
            "type" => "textfield",
            "heading" => esc_html__("Width", "madza_builder69"),
            "param_name" => "width",
            "value" => "",
            "description" => "Enter width size."
        ),
        
        array(
            "type" => "textfield",
            "heading" => esc_html__("Height", "madza_builder69"),
            "param_name" => "height",
            "value" => "",
            "description" => "Enter height size."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin Bottom", "madza_builder69"),
            "param_name" => "margin_bottom",
            "value" => "",
            "description" => "Enter bottom margin size."
            
        ),

        
    )
) 
);
}
add_shortcode( 'mt_button', 'mt_button_func' );
	function mt_button_func( $atts ) {

        extract(shortcode_atts(array(
            'space_count' => '',
            'size' => 'small',
            'position' => 'left',
            'color' => '',
            'margin_left' => '',
            'margin_right' => '',
            'text_on_button' => '',
            'margin_top' => '',
            'margin_bottom' => '',
            'link' => '',
            'target' => '',
            'style' => ''
        ), $atts));
			$output2  = "";
			$output2  .= '<span class=" mt_button_span text-' . $position . '">
							<a class="mt_button_holder" target="' . $target . '"  href="'. $link .'" style="margin-top:' . $margin_top . '; margin-bottom:' . $margin_bottom . '; color:' . $color . ' ; margin-right:' . $margin_right . '; margin-left:' . $margin_left . ';">
								<div class="mask1" style="background-color:' . $color . ';"></div>
					        	<div class="mask2" style="background-color:' . $color . ';"></div>
					        	<div class="mask3" style="background-color:' . $color . ';"></div>
					        	<div class="mask4" style="background-color:' . $color . ';"></div>
					        	'. $text_on_button .'
					        </a>
			        	</span>';  
        	
        $output  = '<span class=" mt_button_span text-' . $position . '"><a target="' . $target . '" href="' . $link . '" class="mt-shortcode-button ' . $size . ' text-' . $position . '" style="margin-top:' . $margin_top . '; margin-bottom:' . $margin_bottom . '; color:' . $color . '; border-color:' . $color . ' ; margin-right:' . $margin_right . '; margin-left:' . $margin_left . ';">';
        $output .= '' . $text_on_button . '';
        $output .= '</a></span>';
        
		if ($style=="2") {
        	return $output2;
        } else {
	       return $output; 
        }
    }

add_action( 'vc_before_init', 'mt_button_fields' );
function mt_button_fields() {
vc_map( array(
    "base"        => "mt_button",
    "name"        => esc_html__("Madza Button", "madza_builder69"),
    "class"        => "mb_composer_spacer",
    "icon"      => "icon-wpb-ui-button",
    "category" => "Madza Moduls",
    "params"    => array(
    	array(
            "type" => "textfield",
            "heading" => esc_html__("Text on the button", "madza_builder69"),
            "param_name" => "text_on_button",
            "value" => "Text on the button",
            "description" => "Text on the button."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Link", "madza_builder69"),
            "param_name" => "link",
            "value" => "#",
            "description" => "Add button link, sample: http://www.yourlink.com"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style", "madza_builder69"),
            "param_name" => "style",
            "value" => array('1' => '1', '2' => '2'),
            "description" => "Select button link target."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Target", "madza_builder69"),
            "param_name" => "target",
            "value" => array('_blank' => '_blank', '_self' => '_self', '_parent' => '_parent', '_top' => '_top'),
            "description" => "Select button link target."
        ),
    	array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", "madza_builder69"),
            "param_name" => "color",
            "value" => "#444444",
            "description" => "Select button color, default: #444444"
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Size", "madza_builder69"),
            "param_name" => "size",
            "value" => array('Small' => 'small', 'Normal' => 'normal', 'Large' => 'large', 'Full' => 'full'),
            "description" => "Select button size."
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Position", "madza_builder69"),
            "param_name" => "position",
            "value" => array('Left' => 'left', 'Center' => 'center', 'Right' => 'right'),
            "description" => "Select button position."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin Left", "madza_builder69"),
            "param_name" => "margin_left",
            "value" => "0px",
            "description" => "Enter left margin size."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin Right", "madza_builder69"),
            "param_name" => "margin_right",
            "value" => "0px",
            "description" => "Enter right margin size."
            
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin Top", "madza_builder69"),
            "param_name" => "margin_top",
            "value" => "10px",
            "description" => "Enter top margin size."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin Bottom", "madza_builder69"),
            "param_name" => "margin_bottom",
            "value" => "40px",
            "description" => "Enter bottom margin size."
            
        ),

        
    )
) 
); }

 

add_shortcode( 'madza_custom_post_type', 'madza_custom_post_type_func' );
	function madza_custom_post_type_func( $atts ) {

        extract(shortcode_atts(array(
            'posttype' => '',
            'item_nr' => '',
            'columns' => '',
            'height' => '',
            'sorting' => '',
            'sortingby' => '',
            'include' => '',
            'exclude' => '',
            'nav' => 'none',
            'category' => '',
            'buttonss' =>'Read more',
            'class' => '',
            'css_animation' => '',
        ), $atts));

		global $exclude_single_id;
        if (is_single()) { $exclude = $exclude_single_id;}
        global $post;
		$myposts = get_posts('post_type='. $posttype .'&order='. $sorting .'&orderby='. $sortingby .'&include='. $include .'&exclude='. $exclude .'&posts_per_page='.$item_nr.'&'.$posttype.'_cat='.$category);
		$_home_portfolio = '';
		foreach($myposts as $post){
	
		
			setup_postdata($post);
			
			
                        $term_obj =  wp_get_object_terms(get_the_ID(), 'portfolio_cat');
                        $portfolio_title = $post->post_title;
                        $portfolio_taxonomy = get_the_term_list(get_the_ID(), 'portfolio_cat', '', ' ', '' );
                         $terms_as_text = strip_tags( get_the_term_list( get_the_ID(), 'portfolio_cat', '', ' ', '' ) );
                        $portfolio_title = $post->post_title;
                        $get_text=get_post_meta(get_the_ID(), "madza_portfolio_hover_text", true);
                        $slides = get_post_meta(get_the_ID(),'slides', true);
                        
                        $thumb = get_post_meta(get_the_ID(), 'tz_portfolio_thumb', TRUE); 
						$large_image_lightbox =  get_post_meta(get_the_ID(), 'tz_portfolio_thumb_lightbox', TRUE); 
						$lightbox = get_post_meta(get_the_ID(), 'tz_portfolio_lightbox', TRUE); 
						$portfolio_caption = get_the_excerpt(); 
						$src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), array( 720,405 ), false, '' );
						
						$icon_metabox = get_post_meta(get_the_ID(), 'mt_icon', true);
						
						$icon = "";
						if($posttype=="our-services" or $posttype=="causes" and $icon_metabox!="") { 
					    
					    	$icon = '<i class="fa '. $icon_metabox .'"></i> ';
					    	
					    }
					    
					    $education = "";
					    $staff_class = "";
					    $mt_icons_1 ="";
					    $mt_icons_2 ="";
					    $mt_icons_3 ="";
					    $mt_icons_4 ="";
					    if($posttype=="our-staff") { 
					    
					    	$education = '<p>'. get_post_meta(get_the_ID(),'mt_doctor_education', true). '</p>';
					    	
					    	 if(get_post_meta(get_the_ID(), 'mt_doctor_twitter', true)!=""){ $mt_icons_1 = ' <a class="mt-cpt-social" href="'.get_post_meta(get_the_ID(), 'mt_doctor_twitter', true).'"><i class="mt-staff-icon fa fa-twitter"></i></a> '; }
					    	 if(get_post_meta(get_the_ID(), 'mt_doctor_facebook', true)!=""){ $mt_icons_2 = ' <a class="mt-cpt-social" href="'.get_post_meta(get_the_ID(), 'mt_doctor_facebook', true).'"><i class="mt-staff-icon fa fa-facebook"></i></a> '; }
					    	 if(get_post_meta(get_the_ID(), 'mt_doctor_google', true)!=""){ $mt_icons_3 = ' <a class="mt-cpt-social" href="'.get_post_meta(get_the_ID(), 'mt_doctor_google', true).'"><i class="mt-staff-icon fa fa-google-plus"></i></a> '; }
					    	 if(get_post_meta(get_the_ID(), 'mt_doctor_linked', true)!=""){ $mt_icons_4 = ' <a class="mt-cpt-social" href="'.get_post_meta(get_the_ID(), 'mt_doctor_linked', true).'"><i class="mt-staff-icon fa fa-linkedin"></i></a> '; }
					    	 if(get_post_meta(get_the_ID(), 'mt_doctor_linked', true)!="" or get_post_meta(get_the_ID(), 'mt_doctor_google', true)!="" or get_post_meta(get_the_ID(), 'mt_doctor_facebook', true)!="" or get_post_meta(get_the_ID(), 'mt_doctor_twitter', true)!="") {
								 $staff_class = "mt-staff-class";
					    	}
					    } else {
						    
						    
						    $education = '<p>'. get_post_meta(get_the_ID(),'mt_short_text', true). '</p>';
						    
					    }
					    $mt_icons = $mt_icons_1.''.$mt_icons_2.''.$mt_icons_3.''.$mt_icons_4;
			
					
					     
					     if($columns=="2") { $column = "col-lg-6 col-md-6 col-sm-6"; } 
					     if($columns=="3") { $column = "col-lg-4 col-md-4 col-sm-6"; } 
					     if($columns=="4") { $column = "col-lg-3 col-md-3 col-sm-6"; }
					     if($columns=="")  { $column = "col-lg-4 col-md-4 col-sm-6"; }
					     
					     
					    
					     $foreach = "";
					     
					     if($nav=="1" or $nav=="2" or $nav=="3" or $nav=="4") {
						     $post_cats = wp_get_post_terms( get_the_ID(), $posttype.'_cat' );
						     foreach( $post_cats as $category ) { $foreach .= $category->slug.' '; }
					     }
					     
					     
					     $css_class = "";
						 $_home_portfolio .= '<div class="'.$class.' '.$staff_class.' '. $column .'  '.$css_class.' sorting box-isotop-in '.  $foreach .'" data-category="portfolio">
						  <figure>
								<a href="'. get_permalink().'">'.  get_the_post_thumbnail( get_the_ID(), array(400, $height, 'bfi_thumb' => true) ) .'</a>
								<figcaption>
									<h3>'. $icon .''. get_the_title() .'</h3>
									'.$education .'<div>'.$mt_icons.'</div>
									<a class="mt-cpt-link" href="'. get_permalink().'">'. $buttonss .'</a>
								
								</figcaption>
							</figure>';
						 
						$_home_portfolio .= '</div>';
						$icon = "";
						
						
    			
    		
    		}
    		
    		
    		
				if($nav=="1" or $nav=="2" or $nav=="3" or $nav=="4") {			
					
					$term_obj = get_terms($posttype.'_cat'); 
					
					$_mt_sorting_menu = "";
					
					foreach ($term_obj as $term) { 
								
						$_mt_sorting_menu .= '<li><a href="#" class="close-subnav filter-item" id="'. $term->slug. '" data-filter=".'. $term->slug .'">'. $term->name .'</a></li>';
								
					} 
								 
					$sorting_nav = 	'<ul id="filterm" class="mt-sorting-nav-'. $nav .'"><li class="current"><a href="#" data-filter="*" id="showall" class="selected close-subnav filter-item">All</a></li>'. $_mt_sorting_menu .'</ul>
					
					<script>	
							jQuery(function(){
				    var container = jQuery(".box-isotop'. $class .'");
				
				    container.isotope({
				      itemSelector: ".box-isotop-in",
				      isFitWidth: false
				    });
				
						
				 // filter items when filter link is clicked
						jQuery("#filterm a").click(function(){
							  var selector = jQuery(this).attr("data-filter");
							  container.isotope({ filter: selector });
							  return false;  
						});
				  });
				</script>';
				
				} else {
					
					$sorting_nav = "";
					
				}	 
								 
				wp_reset_query();
								 
				return $sorting_nav.'<div class="row grid box-isotop'. $class .' cs-style-3">'. $_home_portfolio .'</div>'; 
				
        
        $output = $this->startRow($el_position) . $output . $this->endRow($el_position);
        return $output;
    }
    
    add_action( 'vc_before_init', 'madza_custom_post_type_fieldsa' );
	function madza_custom_post_type_fieldsa() {
	vc_map( array(
	    "base"        => "madza_custom_post_type",
	    "name"        => esc_html__("Madza Custom Post Type", "madza_builder69"),
	    "class"        => "mb_composer_spacer",
	    "icon"      => "icon-th",
    "category" => "Madza Moduls",
	    "params"    => array(
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Custom Post Type", "madza_builder69"),
	            "param_name" => "posttype",
	            "value" => "",
	            "description" => esc_html__("Set Custom Post Type. Sample: portfolio, post, causes, our-staff, our-services", "madza_builder69")
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Columns", "madza_builder69"),
	            "param_name" => "columns",
	            "value" => array(4, 3, 2)
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Nav", "madza_builder69"),
	            "param_name" => "nav",
	            "value" => array('None' => 'none', 'Sorting style 1' => '1', 'Sorting style 2' => '2', 'Sorting style 3' => '3', 'Sorting style 4' => '4'),
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Show Items", "madza_builder69"),
	            "param_name" => "item_nr",
	            "value" => array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Show only category", "madza_builder69"),
	            "param_name" => "category",
	            "value" => "",
	            "description" => esc_html__("Set category slug.", "madza_builder69")
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Sorting", "madza_builder69"),
	            "param_name" => "sorting",
	            "value" => array('DESC' => 'DESC', 'ASC' => 'ASC'),
	        ),
	        array(
	            "type" => "dropdown",
	            "heading" => esc_html__("Sorting By", "madza_builder69"),
	            "param_name" => "sortingby",
	            "value" => array('none' => 'none', 'Order by ID' => 'ID', 'Order by author' => 'author', 'Order by title' => 'title', 'Order by date' => 'date', 'Order by last modified date' => 'modified', 'Order by post/page parent id' => 'parent', 'Random order' => 'rand', 'Order by number of comments' => 'comment_count'),
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Include", "madza_builder69"),
	            "param_name" => "include",
	            "description" => esc_html__("Include post ID, Sample: 34, 2, 12", "madza_builder69"),
	            "value" => "",
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Exclude", "madza_builder69"),
	            "param_name" => "exclude",
	            "description" => esc_html__("Exclude post ID, Sample: 14, 12, 32", "madza_builder69"),
	            "value" => "",
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Image Height", "madza_builder69"),
	            "param_name" => "height",
	            "value" => "280",
	            "description" => esc_html__("Set image height (px)", "madza_builder69")
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("Button Name", "madza_builder69"),
	            "param_name" => "buttonss",
	            "value" => "Read More"
	        ),
	        array(
	            "type" => "textfield",
	            "heading" => esc_html__("class", "madza_builder69"),
	            "param_name" => "class",
	            "value" => ""
	        ),
	        array(
			  "type" => "dropdown",
			  "heading" => esc_html__("CSS Animation", "madza_builder69"),
			  "param_name" => "css_animation",
			  "admin_label" => true,
			  "value" => array(__("No", "madza_builder69") => '', esc_html__("Top to bottom", "madza_builder69") => "top-to-bottom", esc_html__("Bottom to top", "madza_builder69") => "bottom-to-top", esc_html__("Left to right", "madza_builder69") => "left-to-right", esc_html__("Right to left", "madza_builder69") => "right-to-left", esc_html__("Appear from center", "madza_builder69") => "appear"),
			  "description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "madza_builder69")
			)
	        
	    )
	) );
	
	}

}
 


/* --------------------------------------------------------------------------------------- List */
 
function ul( $atts, $content = null ) {
	extract( shortcode_atts( array(
            'top' => '15',
            'bottom' => '15',
            'icon' => 'icon-heart',
            'color' => '#444',
            
        ), $atts));
   return '<ul class="mt-ul-shortcode" style="margin-top:'. $top .'px; margin-bottom:'. $bottom .'px;">' . do_shortcode($content) . '</ul>';
}
add_shortcode('ul', 'ul');

function li( $atts, $content = null ) {
	extract( shortcode_atts( array(
            'icon' => 'icon-heart',
            'color' => '#444',
            
        ), $atts));
   return '<li><i style="color:'. $color .';" class="'. $icon .'"></i> ' . do_shortcode($content) . '</li>';
}
add_shortcode('li', 'li');

  
  


/* --------------------------------------------------------------------------------------- Pricing Table Column */

function pricings( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'title' => 'Title',
            'currency' => '$',
            'price' => '100',
            'period' => '',
            'slug' => '',
            'bg' => '',
            'color' => '',
            'text' => '',
            'links' => '',
            'line_up_color' => '#1a1a1a',
            'line_down_color' => '#404040',
            'slug_color' => '#959595',
            
        ), $atts));
        
    if(esc_attr($bg) == 'yes'){ $bg = '-bg'; } 
     
    if(esc_attr($links) != ''){ $linkstart = '<a href="'. esc_attr($links) .'">'; $linkend = '</a>'; } else { $linkstart =""; $linkend =""; } 
    
return  $linkstart .'<div class="mb-pricing-box'. $bg .'" style="background-color:'. esc_attr($color) .'!important;">
	<h3 class="mb-pricing-title" style="color:'. esc_attr($text) .'!important;">'. esc_attr($title) .'</h3><div class="mb-pricing-line" style="background-color:'. esc_attr($line_up_color) .'!important;"></div><div class="mb-pricing-line-2" style="background-color:'. esc_attr($line_down_color) .'!important;"></div><div style="color:'. esc_attr($text) .'!important;"><span class="mb-pricing-value mb-pricing-currency" style="font-size: 30px;">'. esc_attr($currency) .'</span><span class="mb-pricing-value" style="font-size: 91px;">'. esc_attr($price) .'</span><span class="mb-pricing-value" style="font-size: 14px;">'. esc_attr($period) .'</span><br><span class="mb-pricing-slug" style="color: '. esc_attr($slug_color) .'!important; font-size: 11px; ">'. esc_attr($slug) .'</span></div><div class="mb-pricing-line" style="background-color:'. esc_attr($line_up_color) .'!important;"></div><div class="mb-pricing-line-2" style="background-color:'. esc_attr($line_down_color) .'!important;"></div><div class="mb-pricing-content" style="color:'. esc_attr($text) .'!important;">' . do_shortcode($content) . '</div></div>'. $linkend;

}

add_shortcode('pricings', 'pricings');



  
 
function line_padding( $atts) {
	extract( shortcode_atts( array(
            'padding' => '15'
            
        ), $atts));
   return '<div style="padding-top:'. esc_attr($padding) .'px;" class="clear"></div>';
}
add_shortcode('line_padding', 'line_padding');
 
// Shortcode icon
function icon( $atts ) {
    extract( shortcode_atts( array(
            'url' => '',
            'description' => '',
            'float' => 'left'
            
        ), $atts));
        
    if(esc_attr($float) == 'right'){
	   $float = 'float-right';
    } else {
        $float = 'float-left';
    } 
    
    return'<div class="icon-shortcode '. $float .'"><img src="'. esc_attr($url) .'" alt="'. esc_attr($description) .'" /></div>';
}
add_shortcode('icon', 'icon');
 
// Shortcode video half
function shape460( $atts, $content = null ) {
   return'<div class="shape-460">' . do_shortcode($content) . '</div>';
}
add_shortcode('shape460', 'shape460');

// Last 3 Featured Posts
function posts( $atts) {
    extract( shortcode_atts( array(
            'category' => 'Featured'
            
        ), $atts));
    
    $temp = $wp_query;
    $wp_query= null;
    $wp_query = new WP_Query();
    $wp_query->query('category_name='. esc_attr($category) .'&posts_per_page=3');
        
    return'<div>koks</div>';
    
    
    while ($wp_query->have_posts()) : $wp_query->the_post();   
    
    the_title();
    
    the_excerpt();
    
    the_post_thumbnail('show-image');
    
    
    endwhile;
    $wp_query = null; $wp_query = $temp;
    wp_reset_query(); 
}        
add_shortcode('posts', 'posts'); 
 
// Shortcode blockquote
function blockquote( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'align' => ''
            
        ), $atts));
        
   return'<blockquote class="'. esc_attr($align) .'">' . do_shortcode($content) . '</blockquote>';
}
add_shortcode('blockquote', 'blockquote');

// Shortcode dropcaps
function dropcaps( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'style' => '',
            'background' => 'black',
            'font' => 'white'
            
        ), $atts));
        
    if(esc_attr($style) == 'circular'){
	$style = 'style="background-color:'. esc_attr($background) .'; color:'. esc_attr($font) .';"';
    }  
    
    return'<div class="dropcaps '. esc_attr($style) .'" '. $style .'>' . do_shortcode($content) . '</div>';
}
add_shortcode('dropcaps', 'dropcaps');

// Shortcode image
function image( $atts) {
    extract( shortcode_atts( array(
            'url' => ''
            
        ), $atts));
        
   return'<img class="image-class" src="'. esc_attr($url) .'">';
}
add_shortcode('image', 'image');

function button_simple($atts, $content = null ){
    extract( shortcode_atts( array(
            'color' => 'black',
            'url' => ''
        ), $atts));
        
        return 
        '<a class="button-shortcode  '. esc_attr($color) .'" href="'. esc_attr($url) .'"><span>'. $content .'</span></a>';
 }
 add_shortcode('button_simple', 'button_simple');
 
function twitter( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'title' => '',
            'rows' => '5',
            'user' => '',
        ), $atts));
        
   return '<div class="twitter_widget">
   
    <ul id="twitter_update_list"></ul>
    
    
    <script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
    <script type="text/javascript" src="http://twitter.com/statuses/user_timeline/'. esc_attr($user) .'.json?callback=twitterCallback2&amp;count='. esc_attr($rows) .'"></script>
    <!-- END Twitter Widget -->
  
   </div>';
}
add_shortcode('twitter', 'twitter');

function contactform( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'title' => 'Contact Form',
            'rows' => '10',
            'email' => '',
            'value' => 'Send Message'
        ), $atts));
        
   return 
   
    '<h2>'. esc_attr($title) .'</h2>
    <div class="widget_chortcode">
        <div id="contact_form_holder_2">
                <form action="'. get_template_directory_uri() .'/includes/send_email.php" method="post" id="contact_form">
                
                <div><label>Name:</label><input value="" type="text" name="name" id="name"></div>
                
                <div class="clear"></div>
                <div><label>E-mail:</label><input type="text2" name="email" id="email" ></div>
                <input type="text" name="email_to" style="display: none;" value="'. esc_attr($email) .'" id="subject">
                <input type="text" name="subject" style="display: none;" value="Contact Form" id="subject">
                <div><textarea name="message" rows="'. esc_attr($rows) .'" id="message"></textarea></div>
                
                
                
                <input type="submit"  id="send_message" value="'. esc_attr($value) .'">
                <div class="clear"></div>
                <div id="mail_success" class="success"><img src="'.  get_template_directory_uri().'/images/success.png"> Thank You!</div>
                <div id="mail_fail" class="error"><img src="'.  get_template_directory_uri() .'/images/error.png"> Sorry! Try later.</div>
                
                </form>  
            </div>
        </div>';
}
add_shortcode('contactform', 'contactform');

function flickr( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'title' => 'Flickr',
            'images' => '10',
            'display' => 'random',
            'size' => 's',
            'layout' => 'x',
            'source' => 'user',
            'id' => ''
        ), $atts));
        
   return 
   
    '
    <div class="widget_chortcode">
        <div id="flickr">
            <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count='. esc_attr($images) .'&amp;display='. esc_attr($display) .'&amp;size='. esc_attr($size) .'&amp;layout='. esc_attr($layout) .'&amp;source='. esc_attr($source) .'&amp;user='. esc_attr($id) .'"></script> </div><div class="clear"></div></div>';
}
add_shortcode('flickr', 'flickr');

function contact_info( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'title' => '',
            'phone' => '',
            'email' => '',
            'address' => '',
            'name' => ''
        ), $atts));
        
   return 
   
    '<h2>'. esc_attr($title) .'</h2> 
        <div class="contact_info_wrap"> 
            <p><span class="icon_text icon_phone silver">'. esc_attr($phone) .'</span></p>
            <p><span class="icon_text icon_mail silver"><a href="mailto:'. esc_attr($email) .'">'. esc_attr($email) .'</a></span></p>
            <p><span class="icon_text icon_home silver">'. esc_attr($address) .'</span></p>
            <p><span class="icon_text icon_person silver">'. esc_attr($name) .'</span></p>
        </div> ';
}

add_shortcode('contact_info', 'contact_info');

function icon_text( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'type' => '',
            'color' => ''
            
        ), $atts));
        
   return'<span class="icon_text '. esc_attr($type) .' '. esc_attr($color) .'">' . do_shortcode($content) . '</span>';
}
add_shortcode('icon_text', 'icon_text');

function icon_link( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'type' => '',
            'url' => '',
            'color' => ''
            
        ), $atts));
        
   return'<a class="icon_text '. esc_attr($type) .' '. esc_attr($color) .'" href="'. esc_attr($url) .'">' . do_shortcode($content) . '</a>';
}
add_shortcode('icon_link', 'icon_link');

function list_icon( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'type' => '',
            'color' => ''
            
        ), $atts));
        
   return'<div class="list_icon '. esc_attr($type) .' '. esc_attr($color) .'">' . do_shortcode($content) . '</div>';
}
add_shortcode('list_icon', 'list_icon');

function frame_box( $atts, $content = null ) {
   return '<div class="frame_box">' . do_shortcode($content) . '</div>';
}
add_shortcode('frame_box', 'frame_box');



function toogle( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'title' => ''
            
        ), $atts));
   return '<div class="toogle_section">
   				<div class="toogle_title inactive2">
   					<div class="widget_span toggle-title">'. esc_attr($title) .'</div>
        		<div class="clear"></div></div>
        		<div class="toogle_options">' . $content . '<div class="clear"></div></div>
        	</div>';
}
add_shortcode('toogle', 'toogle');

function note_box( $atts, $content = null ) {
   return '<div class="note_box">' . do_shortcode($content) . '</div>';
}
add_shortcode('note_box', 'note_box');

function succes( $atts, $content = null ) {
   return '<div class="succes_box">' . do_shortcode($content) . '</div>';
}
add_shortcode('succes', 'succes');

function error( $atts, $content = null ) {
   return '<div class="error_box">' . do_shortcode($content) . '</div>';
}
add_shortcode('error', 'error');

function info( $atts, $content = null ) {
   return '<div class="info_box">' . do_shortcode($content) . '</div>';
}
add_shortcode('info', 'info');

function notice( $atts, $content = null ) {
   return '<div class="notice_box">' . do_shortcode($content) . '</div>';
}
add_shortcode('notice', 'notice');


function infobox_error( $atts, $content = null ) {
   return '<div class="infobox_error">' . do_shortcode($content) . '</div>';
}
add_shortcode('infobox_error', 'infobox_error');

function infobox_info( $atts, $content = null ) {
   return '<div class="infobox_info">' . do_shortcode($content) . '</div>';
}
add_shortcode('infobox_info', 'infobox_info');

function infobox_alert( $atts, $content = null ) {
   return '<div class="infobox_alert">' . do_shortcode($content) . '</div>';
}
add_shortcode('infobox_alert', 'infobox_alert');

function infobox_download( $atts, $content = null ) {
   return '<div class="infobox_download">' . do_shortcode($content) . '</div>';
}
add_shortcode('infobox_download', 'infobox_download');

function infobox_success( $atts, $content = null ) {
   return '<div class="infobox_success">' . do_shortcode($content) . '</div>';
}
add_shortcode('infobox_success', 'infobox_success');


// Shortcode Highlight Style

function highlight_yellow( $atts, $content = null ) {
   return '<span class="highlight_yellow">' . $content . '</span>';
}
add_shortcode('highlight_yellow', 'highlight_yellow');

function highlight_red( $atts, $content = null ) {
   return '<span class="highlight_red">' . $content . '</span>';
}
add_shortcode('highlight_red', 'highlight_red');

function highlight_green( $atts, $content = null ) {
   return '<span class="highlight_green">' . $content . '</span>';
}
add_shortcode('highlight_green', 'highlight_green');

function highlight_blue( $atts, $content = null ) {
   return '<span class="highlight_blue">' . $content . '</span>';
}
add_shortcode('highlight_blue', 'highlight_blue');

function highlight_black( $atts, $content = null ) {
   return '<span class="highlight_black">' . $content . '</span>';
}
add_shortcode('highlight_black', 'highlight_black');


// Shortcode Column Style
function one_sixth( $atts, $content = null ) {
    return '<div class="one_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_sixth', 'one_sixth');

function one_fourth( $atts, $content = null ) {
   return '<div class="one_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fourth', 'one_fourth');

function one_fourth_last( $atts, $content = null ) {
   return '<div class="one_fourth_last">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('one_fourth_last', 'one_fourth_last');

function one_fifth( $atts, $content = null ) {
    return '<div class="one_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fifth', 'one_fifth');

function one_fifth_last( $atts, $content = null ) {
   return '<div class="one_fifth_last">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('one_fifth_last', 'one_fifth_last');

function one_third( $atts, $content = null ) {
   return '<div class="one_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_third', 'one_third');

function one_third_last( $atts, $content = null ) {
   return '<div class="one_third_last">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('one_third_last', 'one_third_last');

function one_half( $atts, $content = null ) {
    
   return '<div class="one_half">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_half', 'one_half');

function one_half_last( $atts, $content = null ) {
   return '<div class="one_half_last">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('one_half_last', 'one_half_last');

function two_third( $atts, $content = null ) {
   return '<div class="two_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_third', 'two_third');

function two_third_last( $atts, $content = null ) {
   return '<div class="two_third_last">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('two_third_last', 'two_third_last');

function three_fourth( $atts, $content = null ) {
   return '<div class="three_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fourth', 'three_fourth');

function three_fourth_last( $atts, $content = null ) {
   return '<div class="three_fourth_last">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('three_fourth_last', 'three_fourth_last');

// Shortcode OTHER

function title( $atts, $content = null ) {
   return '<div class="title">' . do_shortcode($content) . '</div>';
}
add_shortcode('title', 'title');

function top() {
return '<div class="back-top"><div class="back-top-left"></div><div class="back-top-right"><a href="#">Top</a></div><div class="clear"></div></div>'; }
add_shortcode('top', 'top');



function line( $atts, $content = null ) {
    extract( shortcode_atts( array(
            'space_top' => '5',
            'space_bottom' => '15'
            
        ), $atts));
        
   return'<div class="line_shortcut" style="margin-top:'. esc_attr($space_top) .'px; padding-bottom:'. esc_attr($space_bottom) .'px;">' . do_shortcode($content) . '</div><div class="clear"></div>';
}
add_shortcode('line', 'line');

function line_zero() {
return '<div class="line_zero"></div>'; } 
add_shortcode('line_zero', 'line_zero');

function clear() {
return '<div class="clear"></div>'; } add_shortcode('clear', 'clear');
add_shortcode('clear', 'clear');

function code( $atts, $content = null ) {
   return '<code class="codess">' . $content . '</code>';
}
add_shortcode('code', 'code');

function linespace() {
return '<div class="linespace"></div>'; } 
add_shortcode('linespace', 'linespace');




function portfolio($atts) {
	extract( shortcode_atts( array(
        	'title' => 'Recent portfolio',
        	'description' => '',
            
        ), $atts));

	global $post;
		$myposts = get_posts('post_type=portfolio&order=DESC&posts_per_page=6');
		$_home_portfolio = '';
		foreach($myposts as $post){
	
		
			setup_postdata($post);
			
			
                        $term_obj =  wp_get_object_terms(get_the_ID(), 'portfolio_cat');
                        $portfolio_title = $post->post_title;
                        $portfolio_taxonomy = get_the_term_list(get_the_ID(), 'portfolio_cat', '', ' ', '' );
                         $terms_as_text = strip_tags( get_the_term_list( get_the_ID(), 'portfolio_cat', '', ' ', '' ) );
                        $portfolio_title = $post->post_title;
                        $get_text=get_post_meta(get_the_ID(), "madza_portfolio_hover_text", true);
                        $slides = get_post_meta(get_the_ID(),'slides', true);
                        
                        $thumb = get_post_meta(get_the_ID(), 'tz_portfolio_thumb', TRUE); 
						$large_image_lightbox =  get_post_meta(get_the_ID(), 'tz_portfolio_thumb_lightbox', TRUE); 
						$lightbox = get_post_meta(get_the_ID(), 'tz_portfolio_lightbox', TRUE); 
						$portfolio_caption = get_post_meta(get_the_ID(), 'tz_portfolio_caption', TRUE); 
						$src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), array( 720,405 ), false, '' );
						
					if (has_post_thumbnail()){     
							$_home_portfolio .= '<li class="home-page-posts-portfolio-frame sorting'. $terms_as_text .' ">';
			
	    			
					$_home_portfolio .= '<div class="hover-madza">';
					
					if($large_image_lightbox != '') { 
	    				$_home_portfolio .= '<a class="portfolio-lightbox-tirangle" data-rel="prettyPhoto[pp_gal]" title="'. get_the_title() .'" href="'. $large_image_lightbox .'"></a>';
	    			 } 
						$_home_portfolio .= '<a class="portfolio-link-tirangle" title="'. get_the_title() .'" href="'. get_permalink() .'"></a>';
								
                       	$_home_portfolio .= '<div class="portfolio_hover home-page-posts-portfolio-frame-hover"></div>';
                                
						 if(has_post_thumbnail()) { $_home_portfolio .= ''.  aq_resize( $src[0], '206', '140', 'false', 'true') .''; } 
									
					$_home_portfolio .= '</div>';
							
					$_home_portfolio .= '<div class="home-page-posts-portfolio-container">';
	                                
	                	$_home_portfolio .= '<a title="'. get_the_title() .'" href="'. get_permalink() .'">'. get_the_title() .'</a>';
	                                    
	                	$_home_portfolio .= '<p>'. substr($portfolio_caption, 0, 30) .'</p>';
	                $_home_portfolio .= '</div>';
	               
    			$_home_portfolio .= '</li>';
    			}
						
    		
    		}
    		
    		wp_reset_query();

return'<div class="clear"></div><div class="homepage-portfolio-div-frame">
	
   	
   	<div class="mb-recent-portfolio"><h5><strong>'. esc_attr($title) .'</strong></h5>
   	<p>'.  esc_attr($description) .'</p>
   	<div class="homepage-portfolio-div-frame-title-button">
			<div id="prev2-portfolio"></div><div id="next2-portfolio"></div></div></div>
   	<ul class="home-ul-port" id="portfolio-home-ul-1" >'. $_home_portfolio .'</ul>
   	<ul class="home-ul-port" id="portfolio-home-ul-2" >'. $_home_portfolio .'</ul>
   	<ul class="home-ul-port-last" id="portfolio-home-ul-3" >'. $_home_portfolio .'</ul>
   	
   	
   	<script type="text/javascript">
   	 jQuery(document).ready(function(){
            jQuery("#portfolio-home-ul-1").cycle({ 
                fx:         "fade", 
                speed:       600,
                timeout:     0,
                next:   "#next2-portfolio", 
   				prev:   "#prev2-portfolio",
                easing: "easeInExpo",
                startingSlide: 0,
                sync: true
            });
            jQuery("#portfolio-home-ul-2").cycle({ 
                fx:         "fade", 
                speed:       500,
                timeout:     0,
                next:   "#next2-portfolio", 
   				prev:   "#prev2-portfolio",
                easing: "easeInExpo",
                startingSlide: 1,
                sync: true
            });
            jQuery("#portfolio-home-ul-3").cycle({ 
                fx:         "fade", 
                speed:       400,
                timeout:     0,
                next:   "#next2-portfolio", 
   				prev:   "#prev2-portfolio",
                easing: "easeInExpo",
                startingSlide: 2,
                sync: true
            });
            jQuery("#portfolio-home-ul-4").cycle({ 
                fx:         "fade", 
                speed:       300,
                timeout:     0,
                next:   "#next2-portfolio", 
   				prev:   "#prev2-portfolio",
                easing: "easeInExpo",
                startingSlide: 3,
                sync: true
            });
        });
   	</script>
   	
   	
   	<div class="clear"></div></div>'; 
    
        
        
 } 
add_shortcode('portfolio', 'portfolio');

function last_posts($atts) {

extract( shortcode_atts( array(
        	'title' => 'Our Last News',
            'url' => '',
            'linkname' => '',
            'posts' => '3',
            'sort' => 'DESC'
            
        ), $atts));
if(esc_attr($url)!="") { $post_link = '<a href="'. esc_attr($url) .'" class="last-news-link">'. esc_attr($linkname) .'</a>'; } else { $post_link = "";}
 global $post;
		$myposts = get_posts('post_type=post&order='. esc_attr($sort) .'&posts_per_page='. esc_attr($posts) .'');

        $_home_portfolio = "";
		foreach($myposts as $post){
			setup_postdata($post);
			$ignore[] = get_the_ID();
			$portfolio_caption = get_the_content();
            
            $_home_portfolio .= '<li class="last-new-shortcode-li">';
           # if ( has_post_thumbnail() ) { $_home_portfolio .= '<div class="post-100-thumb-shortcode">'. get_the_post_thumbnail(get_the_ID(), 'post-70'). '</div>'; }
			$_home_portfolio .= '<div class="post-100-thumb-shortcode-div"><a title="'. get_the_title() .'" href="'. get_permalink() .'">'. get_the_title() .'</a>';
        	
       		$_home_portfolio .= '<p>'. substr($portfolio_caption, 0, 65) .' &hellip;</p>';
       		if ( has_post_thumbnail() ) { $_home_portfolio .= '</div>'; }
       		$_home_portfolio .= '<div class="clear"></div>';     
			$_home_portfolio .= '</li>';
        }

	
return'<div class="widget_span float-left">'. esc_attr($title) .'</div>'. $post_link .'<div class="clear"></div><ul class="last-new-shortcode" >'.  $_home_portfolio .'</ul>';


}
add_shortcode('last_posts', 'last_posts');
?>